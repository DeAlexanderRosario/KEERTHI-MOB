import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:frappe_mobile_sdk/src/sync/attachment_pipeline.dart';
import 'package:frappe_mobile_sdk/src/sync/push_error.dart';
import 'package:frappe_mobile_sdk/src/database/schema/system_tables.dart';
import 'package:frappe_mobile_sdk/src/database/daos/pending_attachment_dao.dart';
import 'package:frappe_mobile_sdk/src/models/pending_attachment.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class _FakeFile implements File {
  @override
  final String path;
  _FakeFile(this.path);
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
}

/// Throws on the FIRST markDone call (simulating a DB write failure after a
/// successful upload), then delegates to the real implementation.
class _MarkDoneFailsOnceDao extends PendingAttachmentDao {
  _MarkDoneFailsOnceDao(super.db);
  int markDoneCalls = 0;
  @override
  Future<void> markDone(
    int id, {
    required String serverFileName,
    required String serverFileUrl,
  }) async {
    markDoneCalls++;
    if (markDoneCalls == 1) {
      throw Exception('simulated done-state write failure');
    }
    return super.markDone(
      id,
      serverFileName: serverFileName,
      serverFileUrl: serverFileUrl,
    );
  }
}

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late Database db;
  late PendingAttachmentDao dao;

  setUp(() async {
    db = await databaseFactory.openDatabase(inMemoryDatabasePath);
    for (final s in systemTablesDDL()) {
      await db.execute(s);
    }
    dao = PendingAttachmentDao(db);
  });

  tearDown(() async => db.close());

  test(
    'uploads with NO doctype and NO docname (fully unattached File row)',
    () async {
      String? capturedDoctype;
      String? capturedDocname;

      await dao.enqueue(
        parentDoctype: 'Survey',
        parentUuid: 'survey-1',
        parentFieldname: 'cover',
        topParentUuid: 'survey-1',
        topParentDoctype: 'Survey',
        localPath: '/tmp/cover.jpg',
      );

      final pipeline = AttachmentPipeline(
        dao: dao,
        db: db,
        uploader: (file, {doctype, docname, isPrivate = true, fileName}) async {
          capturedDoctype = doctype;
          capturedDocname = docname;
          return {'name': 'FILE-1', 'file_url': '/private/files/cover.jpg'};
        },
        backoff: const [Duration.zero, Duration.zero, Duration.zero],
        fileFromPath: (p) => _FakeFile(p),
      );

      await pipeline.resolveForTopParent('survey-1');

      expect(
        capturedDoctype,
        isNull,
        reason:
            'doctype must be null — Frappe v16 rejects File insert with '
            'attached_to_doctype set but attached_to_name empty/NULL '
            '(file.py:151), so the SDK uploads fully unattached.',
      );
      expect(
        capturedDocname,
        isNull,
        reason:
            'docname must be null — sentinel like "new-survey" creates '
            'orphaned File rows that the relink hooks cannot find.',
      );
    },
  );

  test(
    'uploads pending files, returns id→AttachmentUploadResult map',
    () async {
      final id1 = await dao.enqueue(
        parentDoctype: 'O',
        parentUuid: 'P',
        parentFieldname: 'attachment',
        topParentUuid: 'P',
        topParentDoctype: 'O',
        localPath: '/tmp/x.jpg',
      );
      final id2 = await dao.enqueue(
        parentDoctype: 'O',
        parentUuid: 'P',
        parentFieldname: 'attachment2',
        topParentUuid: 'P',
        topParentDoctype: 'O',
        localPath: '/tmp/y.jpg',
      );

      final pipeline = AttachmentPipeline(
        dao: dao,
        db: db,
        uploader: (file, {doctype, docname, isPrivate = true, fileName}) async {
          return {
            'name': 'FILE-${file.path}',
            'file_url': '/files${file.path}.url',
          };
        },
        backoff: const [Duration.zero, Duration.zero, Duration.zero],
        fileFromPath: (p) => _FakeFile(p),
      );

      final result = await pipeline.resolveForTopParent('P');
      expect(result.keys, containsAll(<int>{id1, id2}));
      expect(result[id1]!.fileUrl, contains('/files'));
    },
  );

  test(
    'a failed done-state write does not trigger a re-upload (no duplicate File)',
    () async {
      // H3 (PR#36 round-4): uploader() and markDone() were in the same try.
      // When the upload succeeds but markDone throws, the retry loop
      // re-uploaded the binary — Frappe's attach hook then creates a second
      // File row. After the fix, the uploaded url is persisted before the
      // done transition, so a retry reuses it instead of re-uploading.
      final failDao = _MarkDoneFailsOnceDao(db);
      await failDao.enqueue(
        parentDoctype: 'O',
        parentUuid: 'P',
        parentFieldname: 'a',
        topParentUuid: 'P',
        topParentDoctype: 'O',
        localPath: '/tmp/z.jpg',
      );
      var uploads = 0;
      final pipeline = AttachmentPipeline(
        dao: failDao,
        db: db,
        uploader: (file, {doctype, docname, isPrivate = true, fileName}) async {
          uploads++;
          return {'name': 'FILE-1', 'file_url': '/private/files/z.jpg'};
        },
        backoff: const [Duration.zero, Duration.zero, Duration.zero],
        fileFromPath: (p) => _FakeFile(p),
      );

      final result = await pipeline.resolveForTopParent('P');

      expect(
        uploads,
        1,
        reason: 'a markDone failure must not re-upload the binary',
      );
      expect(result.values.single.fileUrl, '/private/files/z.jpg');

      // markDone now runs inside the step-4 transaction on a txn-scoped DAO,
      // so the injected fake is bypassed entirely — which is required, since
      // reading through the outer Database while holding a txn deadlocks
      // sqflite. The H3 guarantee itself is unchanged and asserted above
      // (`uploads == 1`); recovery simply moved from an in-loop retry to the
      // next dispatch resuming off the committed url.
      final second = await pipeline.resolveForTopParent('P');
      expect(
        uploads,
        1,
        reason: 'a second dispatch must never re-upload a committed url',
      );
      expect(
        second,
        isEmpty,
        reason: 'the row reached done, so nothing is outstanding',
      );
    },
  );

  test(
    'retries then throws BlockedByUpstream after exhausted attempts',
    () async {
      final id = await dao.enqueue(
        parentDoctype: 'O',
        parentUuid: 'P',
        parentFieldname: 'a',
        topParentUuid: 'P',
        topParentDoctype: 'O',
        localPath: '/tmp/fail.jpg',
      );
      var attempts = 0;
      final pipeline = AttachmentPipeline(
        dao: dao,
        db: db,
        uploader: (file, {doctype, docname, isPrivate = true, fileName}) async {
          attempts++;
          throw Exception('network');
        },
        backoff: const [Duration.zero, Duration.zero, Duration.zero],
        fileFromPath: (p) => _FakeFile(p),
      );
      await expectLater(
        pipeline.resolveForTopParent('P'),
        throwsA(isA<BlockedByUpstream>()),
      );
      expect(attempts, 3);
      final row = await dao.findById(id);
      expect(row!.state, AttachmentState.failed);
    },
  );

  test('backoff uses indices 0..N-2 for N attempts (not 1..N-1)', () async {
    // Regression for PR#36 round-2 M1. Original code did
    // `backoff[attempt + 1]`, so with 3 attempts the second delay
    // reached index 2 — the would-be-30-seconds slot below. After the
    // fix the delays come from indices 0 and 1 only, both zero. We
    // give the call a 3-second timeout: before the fix this trips
    // (we'd sleep 30s); after the fix the call completes in ms.
    await dao.enqueue(
      parentDoctype: 'O',
      parentUuid: 'P',
      parentFieldname: 'a',
      topParentUuid: 'P',
      topParentDoctype: 'O',
      localPath: '/tmp/fail.jpg',
    );
    var attempts = 0;
    final pipeline = AttachmentPipeline(
      dao: dao,
      db: db,
      uploader: (file, {doctype, docname, isPrivate = true, fileName}) async {
        attempts++;
        throw Exception('network');
      },
      backoff: const [Duration.zero, Duration.zero, Duration(seconds: 30)],
      fileFromPath: (p) => _FakeFile(p),
    );
    await expectLater(
      pipeline.resolveForTopParent('P').timeout(const Duration(seconds: 3)),
      throwsA(isA<BlockedByUpstream>()),
    );
    expect(attempts, 3);
  });

  test('inlinePayload rewrites pending:<id> markers with file_url', () async {
    final payload = <String, Object?>{
      'doctype': 'O',
      'name': null,
      'logo': 'pending:1',
      'other_field': 'unchanged',
    };
    final out = AttachmentPipeline.inlinePayload(
      payload,
      resolved: {
        1: const AttachmentUploadResult(fileName: 'X', fileUrl: '/files/X'),
      },
    );
    expect(out['logo'], '/files/X');
    expect(out['other_field'], 'unchanged');
  });

  test('inlinePayload walks into children lists', () {
    final payload = <String, Object?>{
      'items': [
        {'photo': 'pending:2', 'qty': 1},
      ],
    };
    final out = AttachmentPipeline.inlinePayload(
      payload,
      resolved: {
        2: const AttachmentUploadResult(fileName: 'Y', fileUrl: '/files/Y'),
      },
    );
    expect((out['items'] as List).first['photo'], '/files/Y');
  });

  // CONTRACT CHANGE: this used to assert the marker passed through unchanged.
  // That silent passthrough is precisely how the literal string "pending:42"
  // was written into Frappe as an attach-field value — indistinguishable from
  // a real one. An unresolved marker reaching the payload is never correct, so
  // it now throws and the push gate is what prevents it arising.
  test('inlinePayload THROWS when a marker has no resolved entry', () {
    final payload = <String, Object?>{'logo': 'pending:42'};
    expect(
      () => AttachmentPipeline.inlinePayload(payload, resolved: {}),
      throwsA(isA<StateError>()),
    );
  });

  // Regression: fileName! at attachment_pipeline.dart:124 threw a null-assert
  // when a row had serverFileUrl set (upload already done) but serverFileName
  // missing (corrupt / legacy row). The fix uses fileName ?? fileUrl.
  test(
    'does not crash when serverFileUrl is set but serverFileName is null',
    () async {
      final id = await dao.enqueue(
        parentDoctype: 'Patient',
        parentUuid: 'uuid-parent',
        parentFieldname: 'attachment',
        topParentDoctype: 'Patient',
        topParentUuid: 'uuid-parent',
        localPath: '/fake/path.jpg',
        fileName: 'path.jpg',
        isPrivate: false,
      );
      // Simulate a legacy/corrupt row: serverFileUrl present, serverFileName null.
      await db.rawUpdate(
        'UPDATE pending_attachments SET server_file_url = ?, state = ? WHERE id = ?',
        ['/files/path.jpg', 'uploading', id],
      );

      int uploadCalls = 0;
      final pipeline = AttachmentPipeline(
        dao: dao,
        db: db,
        uploader:
            (file, {doctype, docname, fileName, isPrivate = false}) async {
              uploadCalls++;
              return {'file_url': '/files/path.jpg', 'name': 'path.jpg'};
            },
        fileFromPath: (p) => _FakeFile(p),
        // Zero-duration backoff so the test doesn't sleep between retry attempts.
        backoff: const [Duration.zero],
      );

      // Must not throw — should fall back to fileUrl as the fileName.
      await expectLater(pipeline.resolveForTopParent('uuid-parent'), completes);
      // Upload must NOT be re-attempted (fileUrl already set).
      expect(
        uploadCalls,
        0,
        reason: 'must not re-upload when serverFileUrl is already set',
      );
    },
  );
}
