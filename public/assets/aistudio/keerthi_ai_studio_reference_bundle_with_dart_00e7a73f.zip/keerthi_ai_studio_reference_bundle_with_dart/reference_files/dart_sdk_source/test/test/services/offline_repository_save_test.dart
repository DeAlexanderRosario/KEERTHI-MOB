import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:frappe_mobile_sdk/src/api/client.dart';
import 'package:frappe_mobile_sdk/src/database/app_database.dart';
import 'package:frappe_mobile_sdk/src/database/table_name.dart';
import 'package:frappe_mobile_sdk/src/models/doc_field.dart';
import 'package:frappe_mobile_sdk/src/models/doc_type_meta.dart';
import 'package:frappe_mobile_sdk/src/models/offline_mode.dart';
import 'package:frappe_mobile_sdk/src/services/local_writer.dart';
import 'package:frappe_mobile_sdk/src/services/offline_repository.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

DocTypeMeta _customerMeta() => DocTypeMeta(
  name: 'Customer',
  isTable: false,
  fields: [
    DocField(fieldname: 'customer_name', fieldtype: 'Data'),
    DocField(fieldname: 'amount', fieldtype: 'Currency'),
  ],
);

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late AppDatabase appDb;
  late OfflineRepository repo;

  setUp(() async {
    appDb = await AppDatabase.inMemoryDatabase();
    final localWriter = LocalWriter(
      appDb.rawDatabase,
      (_) async => _customerMeta(),
    );
    repo = OfflineRepository(
      appDb,
      localWriter: localWriter,
      offlineMode: const OfflineMode(enabled: true, isPersisted: true),
      client: FrappeClient('http://localhost'),
      metaFetcher: (_) async => _customerMeta(),
    );
    // Persist metaJson so DAO updates (setTableName / saveDocument's
    // _loadMeta) hit a real row. Production: MetaService.getMeta does
    // this before any save can happen.
    await appDb.doctypeMetaDao.upsertMetaJson(
      'Customer',
      jsonEncode(_customerMeta().toJson()),
    );
    await repo.ensureSchemaForClosure(
      metas: {'Customer': _customerMeta()},
      childDoctypes: const {},
    );
  });

  tearDown(() async => appDb.close());

  test(
    'saveDocument INSERT writes docs__ row + outbox row in one txn',
    () async {
      final uuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Acme', 'amount': 100},
      );
      expect(uuid, isNotEmpty);
      final docs = await appDb.rawDatabase.query(
        normalizeDoctypeTableName('Customer'),
      );
      expect(docs.length, 1);
      expect(docs[0]['mobile_uuid'], uuid);
      expect(docs[0]['sync_status'], 'dirty');
      expect(docs[0]['sync_op'], 'INSERT');
      expect(docs[0]['customer_name'], 'Acme');

      final outbox = await appDb.rawDatabase.query('outbox');
      expect(outbox.length, 1);
      expect(outbox[0]['operation'], 'INSERT');
      expect(outbox[0]['mobile_uuid'], uuid);
    },
  );

  test('saveDocument UPDATE captures push_base_payload once', () async {
    final uuid = await repo.saveDocument(
      doctype: 'Customer',
      data: {'customer_name': 'Acme', 'amount': 100},
    );
    // Promote to synced (simulates a successful push).
    await appDb.rawDatabase.update(
      normalizeDoctypeTableName('Customer'),
      {
        'sync_status': 'synced',
        'server_name': 'CUST-001',
        'push_base_payload': null,
      },
      where: 'mobile_uuid = ?',
      whereArgs: [uuid],
    );
    await appDb.rawDatabase.delete('outbox');

    // First edit — base captured.
    await repo.saveDocument(
      doctype: 'Customer',
      data: {'mobile_uuid': uuid, 'customer_name': 'Acme2', 'amount': 100},
    );
    final firstBase =
        (await appDb.rawDatabase.query(
              normalizeDoctypeTableName('Customer'),
              where: 'mobile_uuid = ?',
              whereArgs: [uuid],
            )).first['push_base_payload']
            as String?;
    expect(firstBase, isNotNull);
    final firstParsed = jsonDecode(firstBase!) as Map;
    expect(firstParsed['customer_name'], 'Acme');

    // Second edit — base must NOT be overwritten.
    await repo.saveDocument(
      doctype: 'Customer',
      data: {'mobile_uuid': uuid, 'customer_name': 'Acme3', 'amount': 200},
    );
    final secondBase =
        (await appDb.rawDatabase.query(
              normalizeDoctypeTableName('Customer'),
              where: 'mobile_uuid = ?',
              whereArgs: [uuid],
            )).first['push_base_payload']
            as String?;
    expect(secondBase, firstBase, reason: 'base preserved across edits');
  });

  test(
    'deleteDocument tombstones synced docs__ row + enqueues DELETE',
    () async {
      final uuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Acme', 'amount': 100},
      );
      // Promote to synced so DELETE doesn't trigger the cancel-INSERT path.
      await appDb.rawDatabase.update(
        normalizeDoctypeTableName('Customer'),
        {'sync_status': 'synced', 'server_name': 'CUST-001'},
        where: 'mobile_uuid = ?',
        whereArgs: [uuid],
      );
      await appDb.rawDatabase.delete('outbox');

      await repo.deleteDocument(doctype: 'Customer', mobileUuid: uuid);

      final docs = await appDb.rawDatabase.query(
        normalizeDoctypeTableName('Customer'),
      );
      expect(docs.length, 1);
      expect(docs[0]['sync_status'], 'deleted');
      expect(docs[0]['sync_op'], 'DELETE');

      final outbox = await appDb.rawDatabase.query('outbox');
      expect(outbox.length, 1);
      expect(outbox[0]['operation'], 'DELETE');
    },
  );

  test(
    'deleteDocument on never-pushed doc cancels INSERT and hard-deletes',
    () async {
      final uuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Acme'},
      );
      await repo.deleteDocument(doctype: 'Customer', mobileUuid: uuid);
      final docs = await appDb.rawDatabase.query(
        normalizeDoctypeTableName('Customer'),
      );
      expect(
        docs,
        isEmpty,
        reason: 'docs__ row hard-deleted when INSERT cancelled',
      );
      final outbox = await appDb.rawDatabase.query('outbox');
      expect(outbox, isEmpty);
    },
  );

  test('deleteDocument rolls back when pending_attachments cleanup fails — '
      'docs__ row + outbox row must remain', () async {
    // Regression for PR#36 B4: previously the inner `on DatabaseException`
    // catch swallowed pending_attachments cleanup failures, then the
    // outer `txn.delete(tableName)` still committed. That left the
    // docs__ row hard-deleted with orphan pending_attachments rows
    // whose `top_parent_uuid` no longer resolves. The uploader would
    // retry those orphans forever.
    //
    // After the fix: the failure escapes the txn boundary, sqflite
    // rolls back, and the caller sees the underlying error.
    final uuid = await repo.saveDocument(
      doctype: 'Customer',
      data: {'customer_name': 'Acme'},
    );

    // Force the in-txn DELETE FROM pending_attachments to throw a
    // no-such-table DatabaseException.
    await appDb.rawDatabase.execute('DROP TABLE pending_attachments');

    Object? caught;
    try {
      await repo.deleteDocument(doctype: 'Customer', mobileUuid: uuid);
    } catch (e) {
      caught = e;
    }

    expect(
      caught,
      isNotNull,
      reason:
          'deleteDocument must surface the pending_attachments delete '
          'failure, not swallow it.',
    );

    // Rollback witness: the cancel-INSERT path would have hard-deleted
    // the docs__ row AND removed the outbox INSERT row. After rollback
    // both must be exactly as saveDocument left them.
    final docs = await appDb.rawDatabase.query(
      normalizeDoctypeTableName('Customer'),
      where: 'mobile_uuid = ?',
      whereArgs: [uuid],
    );
    expect(docs, hasLength(1), reason: 'docs__ row must be rolled back');
    expect(docs.first['sync_status'], 'dirty');
    expect(docs.first['sync_op'], 'INSERT');

    final outbox = await appDb.rawDatabase.query(
      'outbox',
      where: 'mobile_uuid = ?',
      whereArgs: [uuid],
    );
    expect(outbox, hasLength(1), reason: 'outbox row must be rolled back');
    expect(outbox.first['operation'], 'INSERT');
  });

  test(
    'deleteDocument on never-pushed doc also clears its pending_attachments',
    () async {
      // Regression for PR#36 review minor item — without the cleanup, an
      // orphaned attachment row would keep retrying upload against a
      // top_parent_uuid whose docs__ row has been hard-deleted.
      final uuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Acme'},
      );
      // Manually enqueue a pending attachment for this doc.
      await appDb.rawDatabase.insert('pending_attachments', <String, Object?>{
        'parent_doctype': 'Customer',
        'parent_uuid': uuid,
        'parent_fieldname': 'image',
        'top_parent_uuid': uuid,
        'top_parent_doctype': 'Customer',
        'local_path': '/tmp/fake.png',
        'is_private': 1,
        'state': 'pending',
        'retry_count': 0,
        'created_at': DateTime.now().toUtc().millisecondsSinceEpoch,
      });

      await repo.deleteDocument(doctype: 'Customer', mobileUuid: uuid);

      final attachments = await appDb.rawDatabase.query(
        'pending_attachments',
        where: 'top_parent_uuid = ?',
        whereArgs: [uuid],
      );
      expect(
        attachments,
        isEmpty,
        reason: 'pending_attachments orphans must be cleared too',
      );
    },
  );

  test('deleteDocument on synced doc also clears its pending_attachments '
      '(tombstone branch)', () async {
    // Regression for PR#36 B4 second half: previously the tombstone
    // branch had no `pending_attachments` cleanup at all, so any
    // attachments queued against a synced parent leaked forever
    // (uploader kept trying to upload files for a doc that was about
    // to be DELETEd server-side).
    final uuid = await repo.saveDocument(
      doctype: 'Customer',
      data: {'customer_name': 'Acme'},
    );
    // Promote to synced so deleteDocument takes the tombstone branch.
    await appDb.rawDatabase.update(
      normalizeDoctypeTableName('Customer'),
      {'sync_status': 'synced', 'server_name': 'CUST-001'},
      where: 'mobile_uuid = ?',
      whereArgs: [uuid],
    );
    await appDb.rawDatabase.delete('outbox');

    await appDb.rawDatabase.insert('pending_attachments', <String, Object?>{
      'parent_doctype': 'Customer',
      'parent_uuid': uuid,
      'parent_fieldname': 'image',
      'top_parent_uuid': uuid,
      'top_parent_doctype': 'Customer',
      'local_path': '/tmp/fake.png',
      'is_private': 1,
      'state': 'pending',
      'retry_count': 0,
      'created_at': DateTime.now().toUtc().millisecondsSinceEpoch,
    });

    await repo.deleteDocument(doctype: 'Customer', mobileUuid: uuid);

    // docs__ row is tombstoned (not hard-deleted — this is the
    // tombstone branch).
    final docs = await appDb.rawDatabase.query(
      normalizeDoctypeTableName('Customer'),
      where: 'mobile_uuid = ?',
      whereArgs: [uuid],
    );
    expect(docs, hasLength(1));
    expect(docs.first['sync_status'], 'deleted');

    // The attachment must have been swept too.
    final attachments = await appDb.rawDatabase.query(
      'pending_attachments',
      where: 'top_parent_uuid = ?',
      whereArgs: [uuid],
    );
    expect(
      attachments,
      isEmpty,
      reason:
          'tombstone branch must clear pending_attachments so the '
          'uploader does not keep trying against a doc that is queued '
          'for server-side DELETE.',
    );
  });

  test(
    'getDirtyDocuments surfaces dirty + deleted rows after offline saves',
    () async {
      // Two dirty offline saves.
      await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Alpha'},
      );
      final betaUuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Beta'},
      );

      // Promote one to synced, then tombstone it (hits the deleted bucket).
      await appDb.rawDatabase.update(
        normalizeDoctypeTableName('Customer'),
        {'sync_status': 'synced', 'server_name': 'CUST-100'},
        where: 'mobile_uuid = ?',
        whereArgs: [betaUuid],
      );
      await appDb.rawDatabase.delete(
        'outbox',
        where: 'mobile_uuid = ?',
        whereArgs: [betaUuid],
      );
      await repo.deleteDocument(doctype: 'Customer', mobileUuid: betaUuid);

      // Default scan finds both. Filtered scan also finds them.
      final dirtyAll = await repo.getDirtyDocuments();
      expect(dirtyAll.length, 2);
      final statuses = dirtyAll.map((d) => d.status).toSet();
      expect(statuses, containsAll(<String>{'dirty', 'deleted'}));

      final dirtyForCustomer = await repo.getDirtyDocuments(
        doctype: 'Customer',
      );
      expect(dirtyForCustomer.length, 2);

      // Filter to a doctype with no dirty rows → empty.
      final dirtyForOther = await repo.getDirtyDocuments(
        doctype: 'NoSuchDoctype',
      );
      expect(dirtyForOther, isEmpty);
    },
  );

  test(
    'saveDocument does not deadlock when meta cache is empty (DAO read path)',
    () async {
      // Build a fresh repo with NO metaFetcher and a metaResolver that
      // throws — the only way meta can be obtained is via `_loadMeta`'s
      // DAO query. This forces the in-txn deadlock path (a real-DB read
      // queued behind the in-flight write txn) to fire if we ever
      // re-introduce the bug.
      final db2 = await AppDatabase.inMemoryDatabase();
      await db2.doctypeMetaDao.upsertMetaJson(
        'Customer',
        jsonEncode(_customerMeta().toJson()),
      );
      final localWriter = LocalWriter(
        db2.rawDatabase,
        // Throwing resolver — if anyone hits it inside the txn we'll see.
        (_) async => throw StateError('metaResolver should not be called'),
      );
      final repo2 = OfflineRepository(
        db2,
        localWriter: localWriter,
        offlineMode: const OfflineMode(enabled: true, isPersisted: true),
        client: FrappeClient('http://localhost'),
        // No metaFetcher → _loadMeta MUST go through doctypeMetaDao.
      );
      await repo2.ensureSchemaForClosure(
        metas: {'Customer': _customerMeta()},
        childDoctypes: const {},
      );
      // Fast-fail timeout proves we don't deadlock — the bug presented
      // as a 30s lock-warning hang.
      await repo2
          .saveDocument(doctype: 'Customer', data: {'customer_name': 'NoCache'})
          .timeout(const Duration(seconds: 5));
      final rows = await db2.rawDatabase.query(
        normalizeDoctypeTableName('Customer'),
      );
      expect(rows, hasLength(1));
      await db2.close();
    },
  );

  test(
    'deleteDocument does not deadlock when meta cache is empty (DAO read path)',
    () async {
      final db2 = await AppDatabase.inMemoryDatabase();
      await db2.doctypeMetaDao.upsertMetaJson(
        'Customer',
        jsonEncode(_customerMeta().toJson()),
      );
      final localWriter = LocalWriter(
        db2.rawDatabase,
        (_) async => throw StateError('metaResolver should not be called'),
      );
      final repo2 = OfflineRepository(
        db2,
        localWriter: localWriter,
        offlineMode: const OfflineMode(enabled: true, isPersisted: true),
        client: FrappeClient('http://localhost'),
      );
      await repo2.ensureSchemaForClosure(
        metas: {'Customer': _customerMeta()},
        childDoctypes: const {},
      );
      final uuid = await repo2
          .saveDocument(doctype: 'Customer', data: {'customer_name': 'X'})
          .timeout(const Duration(seconds: 5));
      // Drop the cache so deleteDocument's _loadMeta has to hit the DAO.
      repo2.invalidateMetaCache();
      await repo2
          .deleteDocument(doctype: 'Customer', mobileUuid: uuid)
          .timeout(const Duration(seconds: 5));
      await db2.close();
    },
  );

  test(
    'saveDocument on synced doc preserves server_name and routes as UPDATE',
    () async {
      // Create + simulate successful push.
      final uuid = await repo.saveDocument(
        doctype: 'Customer',
        data: {'customer_name': 'Acme'},
      );
      await appDb.rawDatabase.update(
        normalizeDoctypeTableName('Customer'),
        {'sync_status': 'synced', 'server_name': 'CUST-001'},
        where: 'mobile_uuid = ?',
        whereArgs: [uuid],
      );
      await appDb.rawDatabase.delete('outbox');

      // Offline edit of the now-synced doc.
      await repo.saveDocument(
        doctype: 'Customer',
        data: {'mobile_uuid': uuid, 'customer_name': 'Acme Edited'},
      );

      final row = (await appDb.rawDatabase.query(
        normalizeDoctypeTableName('Customer'),
        where: 'mobile_uuid = ?',
        whereArgs: [uuid],
      )).first;

      expect(
        row['server_name'],
        'CUST-001',
        reason: 'server_name must survive an offline edit',
      );
      expect(
        row['sync_status'],
        'dirty',
        reason: 'doc is locally modified and not yet pushed',
      );
      expect(row['sync_op'], 'UPDATE');

      final outbox = await appDb.rawDatabase.query('outbox');
      expect(
        outbox.single['operation'],
        'UPDATE',
        reason: 'push engine must route as UPDATE, not INSERT',
      );
    },
  );

  test('getDirtyDocuments returns empty in online mode', () async {
    // Save offline first so docs__ has rows...
    await repo.saveDocument(
      doctype: 'Customer',
      data: {'customer_name': 'Acme'},
    );
    // ...then build a second repo whose mode is online; it should
    // short-circuit even though docs__ is non-empty.
    final onlineRepo = OfflineRepository(
      appDb,
      offlineMode: const OfflineMode(enabled: false, isPersisted: true),
      client: FrappeClient('http://localhost'),
    );
    expect(await onlineRepo.getDirtyDocuments(), isEmpty);
  });

  test(
    'saveDocument throws StateError (no in-txn hang) when the doctype has no '
    'local meta',
    () async {
      final db2 = await AppDatabase.inMemoryDatabase();
      // No upsertMetaJson for 'Customer' → _loadMeta returns null.
      final localWriter = LocalWriter(
        db2.rawDatabase,
        // Mimics production getMeta: reads the OUTER db handle. If saveDocument
        // re-resolved meta INSIDE the write txn (the old bug) this query would
        // queue behind the txn on sqflite's single non-reentrant lock and hang
        // forever → the 5s timeout below fires. Post-fix it is never reached.
        (_) async {
          await db2.rawDatabase.rawQuery('SELECT 1');
          return _customerMeta();
        },
      );
      final repo2 = OfflineRepository(
        db2,
        localWriter: localWriter,
        offlineMode: const OfflineMode(enabled: true, isPersisted: true),
        client: FrappeClient('http://localhost'),
        // No metaFetcher → the missing parent meta cannot be backfilled.
      );
      // Clean StateError BEFORE the write txn. If saveDocument instead let
      // LocalWriter resolve meta in-txn, the blocking resolver above would
      // deadlock and this would surface as a TimeoutException, not StateError.
      await expectLater(
        repo2
            .saveDocument(doctype: 'Customer', data: {'customer_name': 'X'})
            .timeout(const Duration(seconds: 5)),
        throwsA(isA<StateError>()),
      );
      await db2.close();
    },
  );
}
