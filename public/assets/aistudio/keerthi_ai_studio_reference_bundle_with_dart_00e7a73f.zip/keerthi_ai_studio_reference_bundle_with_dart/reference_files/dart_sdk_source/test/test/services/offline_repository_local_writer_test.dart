import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:frappe_mobile_sdk/src/database/app_database.dart';
import 'package:frappe_mobile_sdk/src/database/schema/child_schema.dart';
import 'package:frappe_mobile_sdk/src/database/schema/parent_schema.dart';
import 'package:frappe_mobile_sdk/src/models/doc_field.dart';
import 'package:frappe_mobile_sdk/src/models/doc_type_meta.dart';
import 'package:frappe_mobile_sdk/src/query/unified_resolver.dart';
import 'package:frappe_mobile_sdk/src/services/local_writer.dart';
import 'package:frappe_mobile_sdk/src/services/offline_repository.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

DocField f(String n, String t, {String? options}) =>
    DocField(fieldname: n, fieldtype: t, label: n, options: options);

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late AppDatabase appDb;
  late OfflineRepository repo;

  // Generic parent doctype with a Link, a Table, and a title field.
  final parentMeta = DocTypeMeta(
    name: 'Order',
    titleField: 'title',
    fields: [
      f('title', 'Data'),
      f('customer', 'Link', options: 'Customer'),
      f('items', 'Table', options: 'Order Item'),
    ],
  );
  // Generic child doctype (istable=1).
  final childMeta = DocTypeMeta(
    name: 'Order Item',
    isTable: true,
    fields: [f('item_name', 'Data'), f('size', 'Data'), f('color', 'Select')],
  );

  setUp(() async {
    appDb = await AppDatabase.inMemoryDatabase();

    // Persist meta JSON so OfflineRepository._loadMeta + LocalWriter's
    // metaResolver can find them.
    await appDb.doctypeMetaDao.upsertMetaJson(
      'Order',
      jsonEncode(parentMeta.toJson()),
    );
    await appDb.doctypeMetaDao.upsertMetaJson(
      'Order Item',
      jsonEncode(childMeta.toJson()),
    );

    // Pre-create the per-doctype tables (the closure-pull would do this
    // in production after login).
    for (final s in buildParentSchemaDDL(
      parentMeta,
      tableName: 'docs__order',
    )) {
      await appDb.rawDatabase.execute(s);
    }
    for (final s in buildChildSchemaDDL(
      childMeta,
      tableName: 'docs__order_item',
    )) {
      await appDb.rawDatabase.execute(s);
    }

    final writer = LocalWriter(appDb.rawDatabase, (dt) async {
      final entity = await appDb.doctypeMetaDao.findByDoctype(dt);
      if (entity == null) throw StateError('no meta for $dt');
      return DocTypeMeta.fromJson(jsonDecode(entity.metaJson));
    });
    repo = OfflineRepository(appDb, localWriter: writer);
  });

  tearDown(() async => appDb.rawDatabase.close());

  test(
    'saveDocument writes parent + splits children into per-doctype tables',
    () async {
      await repo.saveDocument(
        doctype: 'Order',
        data: {
          'mobile_uuid': 'p-uuid-1',
          'title': 'offline order 1',
          'customer': 'CUST-001',
          'items': [
            {'item_name': 'item 1', 'size': 'L', 'color': 'Red'},
            {'item_name': 'item 2', 'size': 'M', 'color': 'Blue'},
          ],
        },
      );

      // Per-doctype parent table.
      final parents = await appDb.rawDatabase.query('docs__order');
      expect(parents.length, 1);
      expect(parents.first['mobile_uuid'], 'p-uuid-1');
      expect(parents.first['server_name'], isNull);
      expect(parents.first['sync_status'], 'dirty');
      expect(parents.first['title'], 'offline order 1');

      // Per-child-doctype table — visible to UnifiedResolver/Link picker.
      final children = await appDb.rawDatabase.query(
        'docs__order_item',
        orderBy: 'idx ASC',
      );
      expect(children.length, 2);
      expect(children[0]['parent_uuid'], 'p-uuid-1');
      expect(children[0]['parent_doctype'], 'Order');
      expect(children[0]['parentfield'], 'items');
      expect(children[0]['idx'], 0);
      expect(children[0]['item_name'], 'item 1');
      expect(children[1]['item_name'], 'item 2');
      expect(children[1]['idx'], 1);
    },
  );

  test(
    'saveDocument (update path) replaces children atomically (delete + insert)',
    () async {
      final uuid = await repo.saveDocument(
        doctype: 'Order',
        data: {
          'mobile_uuid': 'p-uuid-2',
          'title': 'first',
          'items': [
            {'item_name': 'A'},
            {'item_name': 'B'},
            {'item_name': 'C'},
          ],
        },
      );

      // Promote to synced so the second save takes the UPDATE branch.
      await appDb.rawDatabase.update(
        'docs__order',
        {'sync_status': 'synced', 'server_name': 'ORD-001'},
        where: 'mobile_uuid=?',
        whereArgs: [uuid],
      );

      await repo.saveDocument(
        doctype: 'Order',
        data: {
          'mobile_uuid': uuid,
          'title': 'updated',
          'items': [
            {'item_name': 'X'},
          ],
        },
      );

      final children = await appDb.rawDatabase.query(
        'docs__order_item',
        orderBy: 'idx ASC',
      );
      expect(children.length, 1);
      expect(children.first['item_name'], 'X');
    },
  );

  test(
    'applyServerDocument promotes the offline-saved row instead of duplicating',
    () async {
      // Step 1: offline save.
      await repo.saveDocument(
        doctype: 'Order',
        data: {
          'mobile_uuid': 'p-uuid-3',
          'title': 'pending push',
          'customer': 'CUST-001',
          'items': [
            {'item_name': 'offline item'},
          ],
        },
      );

      // Simulate post-push state: server returned ORD-00042. We mirror
      // it via applyServerDocument. PullApply.applyPage skips dirty rows
      // by default (the local edit is presumed authoritative), so we
      // first promote the offline row to synced — the equivalent of what
      // PushEngine._writeBack would do on a successful push.
      await appDb.rawDatabase.update(
        'docs__order',
        {'sync_status': 'synced', 'server_name': 'ORD-00042'},
        where: 'mobile_uuid=?',
        whereArgs: ['p-uuid-3'],
      );

      await repo.applyServerDocument(
        doctype: 'Order',
        serverName: 'ORD-00042',
        data: {
          'mobile_uuid': 'p-uuid-3',
          'name': 'ORD-00042',
          'title': 'pending push',
          'customer': 'CUST-001',
          'modified': '2026-04-27 12:00:00',
          'items': [
            {'name': 'ORDI-001', 'item_name': 'offline item'},
          ],
        },
      );

      // The offline-saved row should be promoted, not duplicated.
      final parents = await appDb.rawDatabase.query('docs__order');
      expect(parents.length, 1, reason: 'must not duplicate after writeback');
      expect(parents.first['mobile_uuid'], 'p-uuid-3');
      expect(parents.first['server_name'], 'ORD-00042');
      expect(parents.first['sync_status'], 'synced');
    },
  );

  test(
    'UnifiedResolver returns offline child rows without sync_status error',
    () async {
      // Offline-save a parent with 2 child rows.
      await repo.saveDocument(
        doctype: 'Order',
        data: {
          'mobile_uuid': 'p-uuid-4',
          'title': 'resolver test',
          'items': [
            {'item_name': 'Alpha', 'size': 'L', 'color': 'Red'},
            {'item_name': 'Beta', 'size': 'S', 'color': 'Green'},
          ],
        },
      );

      // Verify children landed in the child table.
      final childRows = await appDb.rawDatabase.query(
        'docs__order_item',
        where: 'parent_uuid = ?',
        whereArgs: ['p-uuid-4'],
        orderBy: 'idx ASC',
      );
      expect(childRows.length, 2);

      // Build a resolver that reads from the same in-memory DB.
      Future<DocTypeMeta> metaFn(String dt) async {
        final entity = await appDb.doctypeMetaDao.findByDoctype(dt);
        if (entity == null) throw StateError('no meta for $dt');
        return DocTypeMeta.fromJson(jsonDecode(entity.metaJson));
      }

      final resolver = UnifiedResolver(
        db: appDb.rawDatabase,
        metaDao: appDb.doctypeMetaDao,
        isOnline: () => false,
        backgroundFetch: (_, _) async {},
        metaResolver: metaFn,
      );

      // Resolving the CHILD doctype must not throw "no such column: sync_status".
      final result = await resolver.resolve(doctype: 'Order Item');
      expect(result.rows.length, 2);
      expect(
        result.rows.map((r) => r['item_name']).toList(),
        containsAll(['Alpha', 'Beta']),
      );
    },
  );

  test('saveDocument skips an unsynced child (no in-txn hang) when its meta is '
      'not available locally', () async {
    final db2 = await AppDatabase.inMemoryDatabase();
    // Only the parent meta is synced; 'Order Item' is absent.
    await db2.doctypeMetaDao.upsertMetaJson(
      'Order',
      jsonEncode(parentMeta.toJson()),
    );
    for (final s in buildParentSchemaDDL(
      parentMeta,
      tableName: 'docs__order',
    )) {
      await db2.rawDatabase.execute(s);
    }
    // Resolver mimics production getMeta: reads the OUTER db handle. If
    // writeParentInTxn re-resolved the missing child's meta in-txn (the old
    // bug) this query queues behind the txn on sqflite's single non-reentrant
    // lock and hangs forever → the 5s timeout fires. Post-fix the child is
    // skipped, so the resolver is never called.
    final writer = LocalWriter(db2.rawDatabase, (_) async {
      await db2.rawDatabase.rawQuery('SELECT 1');
      return childMeta;
    });
    final repo2 = OfflineRepository(db2, localWriter: writer);
    // The unsynced child is deliberately skipped; the parent still saves
    // (no hang — pre-fix the in-txn child resolver would deadlock here).
    await repo2
        .saveDocument(
          doctype: 'Order',
          data: {
            'mobile_uuid': 'p-skip',
            'title': 'parent only',
            'items': [
              {'item_name': 'dropped'},
            ],
          },
        )
        .timeout(const Duration(seconds: 5));
    final parents = await db2.rawDatabase.query('docs__order');
    expect(
      parents.length,
      1,
      reason: 'parent row written despite skipped child',
    );
    final childTable = await db2.rawDatabase.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND "
      "name='docs__order_item'",
    );
    expect(childTable, isEmpty, reason: 'unsynced child table never created');
    await db2.close();
  });
}
