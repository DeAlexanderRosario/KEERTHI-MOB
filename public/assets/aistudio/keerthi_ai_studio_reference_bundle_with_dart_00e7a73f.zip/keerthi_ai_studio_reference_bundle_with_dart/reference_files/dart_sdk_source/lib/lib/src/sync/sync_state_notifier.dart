import 'dart:async';
import 'sync_state.dart';

/// Holds the latest [SyncState] snapshot and broadcasts every assignment to
/// subscribers. Modelled after `ValueNotifier` but uses a broadcast stream
/// so multiple widgets can listen independently and the SDK can hand out
/// the stream as a public read-only surface.
class SyncStateNotifier {
  SyncState _value = SyncState.initial;
  final StreamController<SyncState> _controller =
      StreamController<SyncState>.broadcast();

  SyncState get value => _value;

  /// Setter short-circuits when [next] is value-equal to the current value
  /// (relies on [SyncState.==]). This means listeners — including widget
  /// trees subscribed via `StreamBuilder` — do not rebuild when a tick of
  /// engine bookkeeping produces an identical snapshot.
  set value(SyncState next) {
    // Drop writes that race teardown. FrappeSDK.dispose() closes this notifier,
    // but an in-flight engine (PushEngine/PullEngine/SyncController all share
    // this instance via SyncEngineBuilder) may be suspended at an await and
    // resume to write a final state tick afterwards. Without this guard that
    // write hits `_controller.add` on a closed broadcast controller and throws
    // StateError, crashing the unawaited sync future during logout/shutdown.
    if (_controller.isClosed) return;
    if (_value == next) return;
    _value = next;
    _controller.add(next);
  }

  Stream<SyncState> get stream => _controller.stream;

  /// Records a per-doctype meta-sync failure on
  /// [SyncState.failedMetaSyncs]. Caller (typically [MetaService]) should
  /// pass the doctype name and a short error description. Idempotent —
  /// re-recording the same `(doctype, error)` is a no-op (short-circuits
  /// via [SyncState.==]).
  void recordMetaSyncFailure(String doctype, String error) {
    final current = _value.failedMetaSyncs;
    if (current[doctype] == error) return;
    final next = Map<String, String>.from(current);
    next[doctype] = error;
    value = _value.copyWith(failedMetaSyncs: next);
  }

  /// Clears a doctype's entry from [SyncState.failedMetaSyncs] — called
  /// after a subsequent successful meta sync to lower the counter. No-op
  /// if no entry exists.
  void clearMetaSyncFailure(String doctype) {
    final current = _value.failedMetaSyncs;
    if (!current.containsKey(doctype)) return;
    final next = Map<String, String>.from(current)..remove(doctype);
    value = _value.copyWith(failedMetaSyncs: next);
  }

  /// Publishes platform connectivity onto [SyncState.isOnline].
  ///
  /// Fed by the SDK's `ConnectivityWatcher` (initial probe + every edge).
  /// Without a publisher, `isOnline` stays at [SyncState.initial]'s `false`
  /// forever and every `SyncStatusBar` renders a permanent "Offline" strip
  /// even while API calls succeed. No-op when the value is unchanged.
  void updateOnline(bool online) {
    if (_value.isOnline == online) return;
    value = _value.copyWith(isOnline: online);
  }

  /// Records [error] on [SyncState.lastError]. Used by the SDK to surface
  /// boot-time / sync-pipeline failures the host app can subscribe to and
  /// turn into UI (e.g. a "couldn't reach server" banner).
  ///
  /// Bypasses [SyncState.copyWith] because the copyWith helper coalesces
  /// `null` to the prior value — it cannot express "set to this error",
  /// only "leave unchanged."
  void recordLastError(SyncErrorSummary error) {
    if (_value.lastError == error) return;
    value = SyncState(
      isOnline: _value.isOnline,
      isInitialSync: _value.isInitialSync,
      isPulling: _value.isPulling,
      isPushing: _value.isPushing,
      isUploading: _value.isUploading,
      isPaused: _value.isPaused,
      perDoctype: _value.perDoctype,
      queue: _value.queue,
      lastError: error,
      lastSyncAt: _value.lastSyncAt,
      failedMetaSyncs: _value.failedMetaSyncs,
    );
  }

  /// Clears [SyncState.lastError]. Called by the SDK at the start of a
  /// fresh sync attempt so the UI banner doesn't linger after the user
  /// retries.
  void clearLastError() {
    if (_value.lastError == null) return;
    value = SyncState(
      isOnline: _value.isOnline,
      isInitialSync: _value.isInitialSync,
      isPulling: _value.isPulling,
      isPushing: _value.isPushing,
      isUploading: _value.isUploading,
      isPaused: _value.isPaused,
      perDoctype: _value.perDoctype,
      queue: _value.queue,
      lastError: null,
      lastSyncAt: _value.lastSyncAt,
      failedMetaSyncs: _value.failedMetaSyncs,
    );
  }

  Future<void> close() => _controller.close();
}
