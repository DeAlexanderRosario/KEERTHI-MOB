import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

typedef OnRestoreCallback = void Function();

/// Tracks online/offline state. Two construction paths:
///
/// - [ConnectivityWatcher.fromStream] — used by tests with a synthetic
///   `Stream<bool>`, no platform plugin.
/// - [ConnectivityWatcher.production] — wires up the real
///   `connectivity_plus` event stream.
///
/// Callers can subscribe to [onChange] for every transition or register
/// one-shot-per-transition `addOnRestoreCallback` handlers that fire only
/// on the offline → online edge (used by the pull engine to drain
/// deferred doctypes).
class ConnectivityWatcher {
  bool _isOnline;
  final StreamController<bool> _controller = StreamController<bool>.broadcast();
  final List<OnRestoreCallback> _onRestoreCallbacks = [];

  /// Subscription on the source stream — stored so [dispose] can cancel it
  /// instead of letting it keep emitting into a closed controller.
  StreamSubscription<bool>? _sub;

  ConnectivityWatcher._(this._isOnline);

  factory ConnectivityWatcher.fromStream({
    required bool initial,
    required Stream<bool> stream,
  }) {
    final w = ConnectivityWatcher._(initial);
    // Guard against errors on the source stream (e.g. connectivity_plus
    // emitting a PlatformException when network-info permission is revoked
    // on Android 13+). Without onError the error is uncaught and crashes the
    // isolate; swallow + log and keep the watcher alive (PR#36 round-4 M1).
    w._sub = stream.listen(
      w._onEvent,
      onError: (Object e, StackTrace st) {
        debugPrint('ConnectivityWatcher: source stream error — $e\n$st');
      },
    );
    return w;
  }

  static Future<ConnectivityWatcher> production() async {
    final connectivity = Connectivity();
    // connectivity_plus throws PlatformException on some Android
    // variants (typically older OEM ROMs missing the network info
    // permission). Letting that propagate would abort FrappeSDK.initialize
    // before any UI is built — a connectivity probe failure must not
    // brick the app. Default to "offline" so the rest of the SDK comes
    // up with safe assumptions; the connectivity stream will still
    // flip to online if a real edge arrives later. (PR#36 round-2 M7)
    var initial = false;
    try {
      initial = !(await connectivity.checkConnectivity()).contains(
        ConnectivityResult.none,
      );
    } catch (e, st) {
      debugPrint(
        'ConnectivityWatcher.production: initial probe failed, '
        'assuming offline — $e\n$st',
      );
    }
    final stream = connectivity.onConnectivityChanged.map(
      (results) => !results.contains(ConnectivityResult.none),
    );
    return ConnectivityWatcher.fromStream(initial: initial, stream: stream);
  }

  bool get isOnline => _isOnline;
  Stream<bool> get onChange => _controller.stream;

  void addOnRestoreCallback(OnRestoreCallback cb) =>
      _onRestoreCallbacks.add(cb);

  void _onEvent(bool nextOnline) {
    // connectivity_plus emits duplicate events on some platforms (e.g.
    // multiple `wifi` events when the OS samples Wi-Fi state). Drop them
    // here so subscribers and `_onRestoreCallbacks` only fire on real
    // edges — the SDK's `_cachedOnline` setter, the SyncStateNotifier,
    // and pull-engine deferred-doctype draining all multiply expensive
    // work on every emit.
    if (nextOnline == _isOnline) return;
    final wasOffline = !_isOnline;
    _isOnline = nextOnline;
    _controller.add(nextOnline);
    if (wasOffline && nextOnline) {
      for (final cb in _onRestoreCallbacks) {
        cb();
      }
    }
  }

  /// Cancels the source-stream subscription and closes the broadcast
  /// controller. Idempotent — safe to call multiple times. After dispose,
  /// further events on the source stream are ignored.
  Future<void> dispose() async {
    await _sub?.cancel();
    _sub = null;
    if (!_controller.isClosed) await _controller.close();
  }
}
