enum LinkFieldPickerMode { inline, dialog }
