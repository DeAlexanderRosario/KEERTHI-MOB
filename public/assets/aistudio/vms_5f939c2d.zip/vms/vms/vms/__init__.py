# Canonical Frappe module 'VMS'
