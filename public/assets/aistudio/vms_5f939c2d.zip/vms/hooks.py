from vms.hooks import *
