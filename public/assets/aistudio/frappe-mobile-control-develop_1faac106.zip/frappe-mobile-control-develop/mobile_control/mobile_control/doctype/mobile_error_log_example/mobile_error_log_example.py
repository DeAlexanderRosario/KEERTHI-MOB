# Copyright (c) 2026, Dhwani RIS and contributors
# For license information, please see license.txt

from frappe.model.document import Document


class MobileErrorLogExample(Document):
	pass
