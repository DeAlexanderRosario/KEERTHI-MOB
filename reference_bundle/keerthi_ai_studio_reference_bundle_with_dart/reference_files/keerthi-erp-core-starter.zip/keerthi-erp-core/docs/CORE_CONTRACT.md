# Core contract

## Invariants

1. The browser calls same-origin `/api/erp` routes; it never receives a Frappe API secret.
2. Server routes forward only a fixed set of operations.
3. The authenticated ERPNext session is attached server-side.
4. Mutations reject requests that fail same-origin validation.
5. ERPNext is authoritative for permission checks and business validation.
6. Create/update/submit operations must not be silently retried.
7. Every request has an explicit loading, success, empty, or error UI state.
8. Errors must be visible to the user and logged without credentials, cookies, or personal data.
9. A hidden UI action is not a permission boundary.
10. Custom endpoints are used only after they are verified on the target site.

## Next modules to build

- Session provider / login screen.
- Role and permission bootstrap from verified Frappe metadata.
- Generic list and form engine.
- Module registry with route-level access checks.
- KPI/report endpoints with bounded server-side queries.
- Integration tests against a non-production ERPNext user and site.
