# Keerthi ERP Core (Next.js App Router)

A reusable TypeScript core for a Next.js ERP web app connected to Frappe/ERPNext v16.
This is a starter integration package, not a claim that your live server endpoints have already been tested.

## Design rules

- Browser code calls same-origin `/api/erp/...` routes only.
- ERPNext base URL is server-only (`ERPNEXT_BASE_URL`); never put API secrets in `NEXT_PUBLIC_*`.
- Login credentials are sent to ERPNext from the server route.
- Frappe `sid` and `csrf_token` are stored in HttpOnly cookies; browser JavaScript cannot read them.
- Mutating requests check `Origin` and same-origin `Host` before proxying.
- The server exposes explicit, constrained operations rather than an unrestricted URL proxy.
- ERPNext remains the authorization source of truth. UI permission checks only improve UX.

## Environment

Add to `.env.local`:

```env
ERPNEXT_BASE_URL=https://erp.keerthigroup.co.in
```

Do not use a trailing slash. Do not prefix this variable with `NEXT_PUBLIC_`.

## Install / merge

Copy `src/lib/erp` into your app's `src/lib/erp` and merge the `src/app/api/erp` routes into your Next.js App Router app. If your app uses `app/` at repository root instead of `src/app/`, move the route folders accordingly.

This package assumes Next.js App Router and TypeScript. It does not replace your existing UI or styling.

## Routes included

- `POST /api/erp/auth/login`
- `POST /api/erp/auth/logout`
- `GET /api/erp/auth/session`
- `GET /api/erp/doctype/[doctype]/meta`
- `GET /api/erp/documents/[doctype]`
- `POST /api/erp/documents/[doctype]`
- `GET /api/erp/documents/[doctype]/[name]`
- `PUT /api/erp/documents/[doctype]/[name]`
- `DELETE /api/erp/documents/[doctype]/[name]`

## Before production

1. Run the app locally and verify login/logout with a test ERPNext user.
2. Verify the `sid` and CSRF cookie behavior on your specific Frappe deployment and reverse proxy.
3. Confirm each endpoint and field against ERPNext v16 and installed custom apps.
4. Add rate limiting to login, audit logging, CSP/security headers, and automated tests.
5. Use least-privilege ERPNext roles. Never rely on hidden navigation as authorization.
6. If cross-site deployment is required, review cookie SameSite and CSRF policy explicitly.
7. Add module-specific reporting endpoints only when the required server-side reports are defined.

## Notes

- Frappe's standard resource APIs are used for CRUD.
- Metadata uses `frappe.desk.form.load.getdoctype`.
- List queries are constrained to a small supported parameter set. Do not expose arbitrary server methods to browsers.
- This starter intentionally does not include custom `mobile_sync.*` or `mobile_auth.*` calls because their availability on the target server must be verified.
