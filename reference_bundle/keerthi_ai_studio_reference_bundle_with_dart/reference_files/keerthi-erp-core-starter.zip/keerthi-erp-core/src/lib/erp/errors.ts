export type ErpErrorCode =
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "VALIDATION"
  | "NOT_FOUND"
  | "CONFLICT"
  | "RATE_LIMITED"
  | "SERVER"
  | "NETWORK"
  | "UNKNOWN";

export class ErpError extends Error {
  constructor(
    message: string,
    public readonly code: ErpErrorCode,
    public readonly status?: number,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = "ErpError";
  }
}

export function toErpError(status: number, body: unknown): ErpError {
  const message = extractMessage(body) ?? `ERP request failed (${status})`;
  if (status === 401) return new ErpError(message, "UNAUTHENTICATED", status, body);
  if (status === 403) return new ErpError(message, "FORBIDDEN", status, body);
  if (status === 404) return new ErpError(message, "NOT_FOUND", status, body);
  if (status === 409) return new ErpError(message, "CONFLICT", status, body);
  if (status === 417 || status === 422) return new ErpError(message, "VALIDATION", status, body);
  if (status === 429) return new ErpError(message, "RATE_LIMITED", status, body);
  if (status >= 500) return new ErpError(message, "SERVER", status, body);
  return new ErpError(message, "UNKNOWN", status, body);
}

export function extractMessage(body: unknown): string | undefined {
  if (!body || typeof body !== "object") return undefined;
  const value = body as Record<string, unknown>;
  if (typeof value.message === "string") return value.message;
  if (typeof value._error_message === "string") return value._error_message;
  if (typeof value.exception === "string") return value.exception;
  return undefined;
}
