import "server-only";
import type { NextRequest } from "next/server";

export function requireSameOrigin(request: NextRequest): Response | null {
  const origin = request.headers.get("origin");
  const host = request.headers.get("host");
  if (!origin || !host) {
    return Response.json({ error: "Origin and Host headers are required." }, { status: 403 });
  }
  try {
    const originUrl = new URL(origin);
    if (originUrl.host !== host || (originUrl.protocol !== "https:" && originUrl.hostname !== "localhost")) {
      return Response.json({ error: "Cross-origin request rejected." }, { status: 403 });
    }
  } catch {
    return Response.json({ error: "Invalid Origin header." }, { status: 403 });
  }
  return null;
}

export function safeDoctype(value: string): boolean {
  return /^[A-Za-z][A-Za-z0-9 _-]{0,119}$/.test(value);
}

export function safeDocumentName(value: string): boolean {
  return value.length > 0 && value.length <= 140 && !value.includes("/") && !value.includes("\\");
}

export function parseJsonParam(value: string | null, fallback: unknown): unknown {
  if (!value) return fallback;
  try { return JSON.parse(value); } catch { throw new Error("Invalid JSON query parameter."); }
}
