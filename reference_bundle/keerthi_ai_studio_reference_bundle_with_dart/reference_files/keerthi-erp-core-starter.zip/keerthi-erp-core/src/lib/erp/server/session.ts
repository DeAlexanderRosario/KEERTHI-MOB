import "server-only";
import { cookies } from "next/headers";

export const SID_COOKIE = "ke_erp_sid";
export const CSRF_COOKIE = "ke_erp_csrf";

export async function sessionCookies() {
  const jar = await cookies();
  return {
    sid: jar.get(SID_COOKIE)?.value,
    csrf: jar.get(CSRF_COOKIE)?.value,
  };
}

export function cookieOptions(maxAge = 60 * 60 * 8) {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge,
  };
}
