import "server-only";

export function erpBaseUrl(): URL {
  const raw = process.env.ERPNEXT_BASE_URL;
  if (!raw) throw new Error("Missing server environment variable ERPNEXT_BASE_URL");
  const url = new URL(raw);
  if (url.protocol !== "https:" && url.hostname !== "localhost" && url.hostname !== "127.0.0.1") {
    throw new Error("ERPNEXT_BASE_URL must use HTTPS outside localhost.");
  }
  url.pathname = url.pathname.replace(/\/+$/, "");
  return url;
}
