import { ErpError } from "./errors";
import type { DocTypeMeta, FrappeEnvelope, JsonRecord, ListQuery } from "./types";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, {
      ...init,
      credentials: "same-origin",
      headers: {
        Accept: "application/json",
        ...(init?.body ? { "Content-Type": "application/json" } : {}),
        ...init?.headers,
      },
    });
  } catch (error) {
    throw new ErpError("Could not reach the web application API.", "NETWORK", undefined, error);
  }

  const text = await response.text();
  let payload: unknown = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = text; }

  if (!response.ok) {
    const body = payload && typeof payload === "object" ? payload as Record<string, unknown> : {};
    const message =
      (typeof body.message === "string" && body.message) ||
      (typeof body.error === "string" && body.error) ||
      `Request failed (${response.status})`;
    const code =
      response.status === 401 ? "UNAUTHENTICATED" :
      response.status === 403 ? "FORBIDDEN" :
      response.status === 404 ? "NOT_FOUND" :
      response.status === 409 ? "CONFLICT" :
      response.status === 417 || response.status === 422 ? "VALIDATION" :
      response.status === 429 ? "RATE_LIMITED" :
      response.status >= 500 ? "SERVER" : "UNKNOWN";
    throw new ErpError(message, code, response.status, payload);
  }
  return payload as T;
}

function unwrap<T>(value: FrappeEnvelope<T> | T): T {
  if (value && typeof value === "object") {
    const env = value as FrappeEnvelope<T>;
    if ("data" in env && env.data !== undefined) return env.data;
    if ("message" in env && env.message !== undefined) return env.message;
  }
  return value as T;
}

const segment = (value: string) => encodeURIComponent(value);

export const erpClient = {
  async login(username: string, password: string): Promise<{ user: string }> {
    return request("/api/erp/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
  },

  async logout(): Promise<void> {
    await request("/api/erp/auth/logout", { method: "POST" });
  },

  async session(): Promise<{ authenticated: boolean; user?: string; fullName?: string }> {
    return request("/api/erp/auth/session");
  },

  async getMeta(doctype: string): Promise<DocTypeMeta> {
    const result = await request<FrappeEnvelope<DocTypeMeta>>(
      `/api/erp/doctype/${segment(doctype)}/meta`,
    );
    return unwrap(result);
  },

  async list<T extends JsonRecord = JsonRecord>(
    doctype: string,
    query: ListQuery = {},
  ): Promise<T[]> {
    const params = new URLSearchParams();
    if (query.fields?.length) params.set("fields", JSON.stringify(query.fields));
    if (query.filters?.length) params.set("filters", JSON.stringify(query.filters));
    if (query.or_filters?.length) params.set("or_filters", JSON.stringify(query.or_filters));
    if (query.order_by) params.set("order_by", query.order_by);
    if (query.limit_start !== undefined) params.set("limit_start", String(query.limit_start));
    if (query.limit_page_length !== undefined) params.set("limit_page_length", String(query.limit_page_length));
    const suffix = params.size ? `?${params.toString()}` : "";
    const result = await request<FrappeEnvelope<T[]>>(
      `/api/erp/documents/${segment(doctype)}${suffix}`,
    );
    return unwrap(result);
  },

  async get<T extends JsonRecord = JsonRecord>(doctype: string, name: string): Promise<T> {
    const result = await request<FrappeEnvelope<T>>(
      `/api/erp/documents/${segment(doctype)}/${segment(name)}`,
    );
    return unwrap(result);
  },

  async create<T extends JsonRecord = JsonRecord>(doctype: string, document: JsonRecord): Promise<T> {
    const result = await request<FrappeEnvelope<T>>(
      `/api/erp/documents/${segment(doctype)}`,
      { method: "POST", body: JSON.stringify(document) },
    );
    return unwrap(result);
  },

  async update<T extends JsonRecord = JsonRecord>(
    doctype: string, name: string, patch: JsonRecord,
  ): Promise<T> {
    const result = await request<FrappeEnvelope<T>>(
      `/api/erp/documents/${segment(doctype)}/${segment(name)}`,
      { method: "PUT", body: JSON.stringify(patch) },
    );
    return unwrap(result);
  },

  async delete(doctype: string, name: string): Promise<void> {
    await request(`/api/erp/documents/${segment(doctype)}/${segment(name)}`, { method: "DELETE" });
  },
};
