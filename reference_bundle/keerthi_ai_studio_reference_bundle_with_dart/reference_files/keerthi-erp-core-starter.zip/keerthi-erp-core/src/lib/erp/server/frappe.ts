import "server-only";
import { cookies } from "next/headers";
import { erpBaseUrl } from "./config";
import { CSRF_COOKIE, SID_COOKIE } from "./session";

export async function frappeFetch(
  path: string,
  init: RequestInit = {},
  requireSession = true,
): Promise<Response> {
  const base = erpBaseUrl();
  const target = new URL(path.replace(/^\/+/, ""), base.toString().replace(/\/?$/, "/"));
  if (target.origin !== base.origin) throw new Error("Blocked non-ERPNext request.");

  const jar = await cookies();
  const sid = jar.get(SID_COOKIE)?.value;
  const csrf = jar.get(CSRF_COOKIE)?.value;
  if (requireSession && !sid) {
    return Response.json({ error: "Authentication required." }, { status: 401 });
  }

  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  if (sid) headers.set("Cookie", `sid=${sid}`);
  if (csrf && init.method && !["GET", "HEAD", "OPTIONS"].includes(init.method.toUpperCase())) {
    headers.set("X-Frappe-CSRF-Token", csrf);
  }
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");

  return fetch(target, {
    ...init,
    headers,
    cache: "no-store",
    redirect: "manual",
    signal: init.signal,
  });
}

export async function frappeJson<T = unknown>(response: Response): Promise<T> {
  const text = await response.text();
  let body: unknown = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = { message: text }; }
  if (!response.ok) {
    const obj = body && typeof body === "object" ? body as Record<string, unknown> : {};
    const message = typeof obj.message === "string" ? obj.message : `ERPNext returned HTTP ${response.status}`;
    return Response.json({ error: message, details: body }, { status: response.status }) as unknown as T;
  }
  return body as T;
}

export function forwardError(response: Response, body: unknown): Response {
  const obj = body && typeof body === "object" ? body as Record<string, unknown> : {};
  return Response.json(
    { error: typeof obj.message === "string" ? obj.message : `ERPNext returned HTTP ${response.status}`, details: body },
    { status: response.status },
  );
}
