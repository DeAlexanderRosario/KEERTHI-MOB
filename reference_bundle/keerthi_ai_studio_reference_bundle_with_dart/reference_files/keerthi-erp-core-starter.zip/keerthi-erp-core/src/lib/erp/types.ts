export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonRecord = Record<string, JsonValue>;

export interface FrappeEnvelope<T> {
  data?: T;
  message?: T;
  exc?: string;
  _server_messages?: string;
}

export interface FrappeUser {
  user: string;
  fullName?: string;
}

export interface FrappeFieldMeta {
  fieldname: string;
  label?: string;
  fieldtype: string;
  reqd?: number | boolean;
  read_only?: number | boolean;
  hidden?: number | boolean;
  options?: string;
  default?: JsonValue;
  in_list_view?: number | boolean;
  idx?: number;
}

export interface DocTypeMeta {
  name: string;
  fields: FrappeFieldMeta[];
  permissions?: Array<{
    role: string;
    read?: number;
    write?: number;
    create?: number;
    delete?: number;
    submit?: number;
    cancel?: number;
    report?: number;
    export?: number;
  }>;
}

export interface ListQuery {
  fields?: string[];
  filters?: unknown[];
  or_filters?: unknown[];
  order_by?: string;
  limit_start?: number;
  limit_page_length?: number;
}

export interface ListResult<T extends JsonRecord = JsonRecord> {
  data: T[];
  total?: number;
}
