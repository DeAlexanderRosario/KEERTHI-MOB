import { NextRequest, NextResponse } from "next/server";
import { frappeFetch } from "@/lib/erp/server/frappe";
import { cookieOptions, SID_COOKIE, CSRF_COOKIE } from "@/lib/erp/server/session";
import { requireSameOrigin } from "@/lib/erp/server/security";

export async function POST(request: NextRequest) {
  const blocked = requireSameOrigin(request);
  if (blocked) return blocked;

  try { await frappeFetch("/api/method/logout", { method: "POST" }); } catch { /* always clear local session */ }
  const response = NextResponse.json({ ok: true });
  response.cookies.set(SID_COOKIE, "", { ...cookieOptions(0), maxAge: 0 });
  response.cookies.set(CSRF_COOKIE, "", { ...cookieOptions(0), maxAge: 0 });
  return response;
}
