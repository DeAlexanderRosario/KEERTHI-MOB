import { NextRequest, NextResponse } from "next/server";
import { frappeFetch } from "@/lib/erp/server/frappe";
import { parseJsonParam, requireSameOrigin, safeDoctype } from "@/lib/erp/server/security";

type Context = { params: Promise<{ doctype: string }> };
const ALLOWED_FIELDS = new Set(["name", "owner", "creation", "modified", "modified_by", "docstatus", "status", "title"]);

export async function GET(request: NextRequest, context: Context) {
  const { doctype } = await context.params;
  if (!safeDoctype(doctype)) return NextResponse.json({ error: "Invalid DocType." }, { status: 400 });
  const incoming = request.nextUrl.searchParams;
  const fieldsRaw = parseJsonParam(incoming.get("fields"), ["name"]);
  const filtersRaw = parseJsonParam(incoming.get("filters"), []);
  const orFiltersRaw = parseJsonParam(incoming.get("or_filters"), []);
  if (!Array.isArray(fieldsRaw) || !fieldsRaw.every((x) => typeof x === "string" && /^[A-Za-z_][A-Za-z0-9_]*$/.test(x))) {
    return NextResponse.json({ error: "Invalid fields parameter." }, { status: 400 });
  }
  if (!Array.isArray(filtersRaw) || !Array.isArray(orFiltersRaw)) {
    return NextResponse.json({ error: "Filters must be JSON arrays." }, { status: 400 });
  }
  const orderBy = incoming.get("order_by") ?? "modified desc";
  if (!/^[A-Za-z_][A-Za-z0-9_]*(?:\s+(?:asc|desc))?$/i.test(orderBy)) {
    return NextResponse.json({ error: "Invalid order_by parameter." }, { status: 400 });
  }
  const limitStart = parseInt(incoming.get("limit_start") ?? "0", 10);
  const limitPageLength = parseInt(incoming.get("limit_page_length") ?? "20", 10);
  if (!Number.isInteger(limitStart) || limitStart < 0 ||
      !Number.isInteger(limitPageLength) || limitPageLength < 1 || limitPageLength > 100) {
    return NextResponse.json({ error: "Invalid pagination parameters." }, { status: 400 });
  }

  const query = new URLSearchParams({
    doctype,
    fields: JSON.stringify(fieldsRaw),
    filters: JSON.stringify(filtersRaw),
    or_filters: JSON.stringify(orFiltersRaw),
    order_by: orderBy,
    limit_start: String(limitStart),
    limit_page_length: String(limitPageLength),
  });
  const upstream = await frappeFetch(`/api/method/frappe.client.get_list?${query.toString()}`);
  const text = await upstream.text();
  let body: unknown;
  try { body = text ? JSON.parse(text) : null; } catch { body = { message: text }; }
  return NextResponse.json(body, { status: upstream.status });
}

export async function POST(request: NextRequest, context: Context) {
  const blocked = requireSameOrigin(request);
  if (blocked) return blocked;
  const { doctype } = await context.params;
  if (!safeDoctype(doctype)) return NextResponse.json({ error: "Invalid DocType." }, { status: 400 });
  let doc: unknown;
  try { doc = await request.json(); } catch { return NextResponse.json({ error: "Invalid JSON." }, { status: 400 }); }
  if (!doc || typeof doc !== "object" || Array.isArray(doc)) {
    return NextResponse.json({ error: "Document body must be a JSON object." }, { status: 400 });
  }
  const upstream = await frappeFetch(`/api/resource/${encodeURIComponent(doctype)}`, {
    method: "POST", body: JSON.stringify(doc),
  });
  const text = await upstream.text();
  let body: unknown;
  try { body = text ? JSON.parse(text) : null; } catch { body = { message: text }; }
  return NextResponse.json(body, { status: upstream.status });
}
