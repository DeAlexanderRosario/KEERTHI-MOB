import { NextRequest, NextResponse } from "next/server";
import { frappeFetch } from "@/lib/erp/server/frappe";
import { safeDoctype } from "@/lib/erp/server/security";

type Context = { params: Promise<{ doctype: string }> };

export async function GET(_request: NextRequest, context: Context) {
  const { doctype } = await context.params;
  if (!safeDoctype(doctype)) return NextResponse.json({ error: "Invalid DocType." }, { status: 400 });
  const url = new URL("/api/method/frappe.desk.form.load.getdoctype", "http://local");
  url.searchParams.set("doctype", doctype);
  const upstream = await frappeFetch(`${url.pathname}${url.search}`);
  const text = await upstream.text();
  let body: unknown;
  try { body = text ? JSON.parse(text) : null; } catch { body = { message: text }; }
  return NextResponse.json(body, { status: upstream.status });
}
