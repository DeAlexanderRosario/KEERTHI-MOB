import { NextRequest, NextResponse } from "next/server";
import { erpBaseUrl } from "@/lib/erp/server/config";
import { cookieOptions, SID_COOKIE, CSRF_COOKIE } from "@/lib/erp/server/session";
import { requireSameOrigin } from "@/lib/erp/server/security";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const blocked = requireSameOrigin(request);
  if (blocked) return blocked;

  let input: unknown;
  try { input = await request.json(); } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const data = input as Record<string, unknown>;
  if (typeof data.username !== "string" || typeof data.password !== "string" ||
      !data.username.trim() || !data.password || data.username.length > 254 || data.password.length > 4096) {
    return NextResponse.json({ error: "Username and password are required." }, { status: 400 });
  }

  let upstream: Response;
  try {
    const url = new URL("/api/method/login", erpBaseUrl());
    upstream = await fetch(url, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ usr: data.username.trim(), pwd: data.password }),
      cache: "no-store",
      redirect: "manual",
    });
  } catch {
    return NextResponse.json({ error: "Could not connect to ERPNext." }, { status: 502 });
  }

  const text = await upstream.text();
  let payload: Record<string, unknown> = {};
  try { payload = text ? JSON.parse(text) as Record<string, unknown> : {}; } catch { /* ignore */ }
  if (!upstream.ok || payload.message !== "Logged In") {
    return NextResponse.json(
      { error: typeof payload.message === "string" ? payload.message : "ERPNext login failed." },
      { status: upstream.status >= 400 && upstream.status < 500 ? upstream.status : 401 },
    );
  }

  // Frappe deployments may combine cookies in different ways. Parse only the named cookies.
  const setCookieHeaders = upstream.headers.getSetCookie?.() ?? [];
  const combined = setCookieHeaders.join("; ");
  const sid = findCookie(setCookieHeaders, "sid") ?? findCookie([combined], "sid");
  const csrf = findCookie(setCookieHeaders, "csrf_token") ?? findCookie([combined], "csrf_token");
  if (!sid) {
    return NextResponse.json(
      { error: "Login response did not include a session cookie. Check the Frappe proxy/cookie configuration." },
      { status: 502 },
    );
  }

  const response = NextResponse.json({
    user: typeof payload.full_name === "string" ? payload.full_name : data.username.trim(),
  });
  response.cookies.set(SID_COOKIE, sid, cookieOptions());
  if (csrf) response.cookies.set(CSRF_COOKIE, csrf, cookieOptions());
  return response;
}

function findCookie(headers: string[], name: string): string | undefined {
  for (const header of headers) {
    const match = header.match(new RegExp(`(?:^|[,;]\\s*)${name}=([^;,\s]+)`));
    if (match?.[1]) return match[1];
  }
  return undefined;
}
