import { NextRequest, NextResponse } from "next/server";
import { frappeFetch } from "@/lib/erp/server/frappe";
import { requireSameOrigin, safeDocumentName, safeDoctype } from "@/lib/erp/server/security";

type Context = { params: Promise<{ doctype: string; name: string }> };

async function relay(upstream: Response) {
  const text = await upstream.text();
  let body: unknown;
  try { body = text ? JSON.parse(text) : null; } catch { body = { message: text }; }
  return NextResponse.json(body, { status: upstream.status });
}

export async function GET(_request: NextRequest, context: Context) {
  const { doctype, name } = await context.params;
  if (!safeDoctype(doctype) || !safeDocumentName(name)) {
    return NextResponse.json({ error: "Invalid DocType or document name." }, { status: 400 });
  }
  return relay(await frappeFetch(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`));
}

export async function PUT(request: NextRequest, context: Context) {
  const blocked = requireSameOrigin(request);
  if (blocked) return blocked;
  const { doctype, name } = await context.params;
  if (!safeDoctype(doctype) || !safeDocumentName(name)) {
    return NextResponse.json({ error: "Invalid DocType or document name." }, { status: 400 });
  }
  let patch: unknown;
  try { patch = await request.json(); } catch { return NextResponse.json({ error: "Invalid JSON." }, { status: 400 }); }
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
    return NextResponse.json({ error: "Update body must be a JSON object." }, { status: 400 });
  }
  return relay(await frappeFetch(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`, {
    method: "PUT", body: JSON.stringify(patch),
  }));
}

export async function DELETE(request: NextRequest, context: Context) {
  const blocked = requireSameOrigin(request);
  if (blocked) return blocked;
  const { doctype, name } = await context.params;
  if (!safeDoctype(doctype) || !safeDocumentName(name)) {
    return NextResponse.json({ error: "Invalid DocType or document name." }, { status: 400 });
  }
  return relay(await frappeFetch(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`, {
    method: "DELETE",
  }));
}
