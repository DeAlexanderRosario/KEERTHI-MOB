import { NextResponse } from "next/server";
import { frappeFetch } from "@/lib/erp/server/frappe";

export const runtime = "nodejs";

export async function GET() {
  const upstream = await frappeFetch("/api/method/frappe.auth.get_logged_user", { method: "GET" });
  const text = await upstream.text();
  let payload: Record<string, unknown> = {};
  try { payload = text ? JSON.parse(text) as Record<string, unknown> : {}; } catch { /* ignore */ }
  if (!upstream.ok) return NextResponse.json({ authenticated: false }, { status: upstream.status });
  const user = typeof payload.message === "string" ? payload.message : "";
  if (!user || user === "Guest") return NextResponse.json({ authenticated: false }, { status: 401 });
  return NextResponse.json({ authenticated: true, user });
}
