import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../api/client.dart';
import '../api/exceptions.dart';
import '../utils/sdk_log.dart';
import '../models/closure_result.dart';
import '../models/dep_graph.dart';
import '../models/doc_type_meta.dart';
import '../models/mobile_form_name.dart';
import '../database/app_database.dart';
import '../database/entities/doctype_meta_entity.dart';
import 'bulk_watermark_probe.dart';
import 'closure_builder.dart';
import 'dependency_graph_builder.dart';
import 'meta_differ.dart';
import 'meta_migration.dart';

/// Max doctypes kept in memory; oldest (LRU) evicted when exceeded.
const int _kMetaCacheMaxSize = 15;

/// Service for managing DocType metadata.
/// Loads only required meta; uses bounded in-memory cache and clears after use for performance.
class MetaService {
  final FrappeClient _client;
  final AppDatabase _database;
  final Map<String, DocTypeMeta> _metaCache = {};
  final List<String> _metaCacheOrder = [];

  /// Fires whenever a per-doctype meta-sync inside
  /// [checkAndSyncDoctypes] fails. Set by [FrappeSDK] once the
  /// [SyncStateNotifier] is built so failures surface on
  /// `SyncState.failedMetaSyncs` instead of being lost to `debugPrint`.
  /// Optional — when null, failures are still logged.
  void Function(String doctype, Object error)? onMetaSyncFailure;

  /// Fires when a previously-failed doctype's meta is successfully
  /// re-fetched, so the SDK can clear the doctype from
  /// `SyncState.failedMetaSyncs`. Optional and paired with
  /// [onMetaSyncFailure].
  void Function(String doctype)? onMetaSyncRecovered;

  /// Fires whenever a doctype's meta JSON is (re)written from the server
  /// in [_upsertMetaJson] — i.e. `checkAndSyncDoctypes`,
  /// `resyncMobileConfiguration`, `prefetch*`, or [getMeta]'s network
  /// branch picked up fresh schema. Wired by `FrappeSDK` to
  /// `OfflineRepository.invalidateMetaCacheFor` so the offline save path's
  /// own per-doctype meta cache cannot serve a session-stale snapshot
  /// after a mid-session refresh (which would silently drop newly-added
  /// fields). Optional — when null, only this service's LRU is cleared.
  void Function(String doctype)? onMetaRefreshed;

  MetaService(this._client, this._database);

  void _putInCache(String doctype, DocTypeMeta meta) {
    if (_metaCache.containsKey(doctype)) {
      _metaCacheOrder.remove(doctype);
    } else {
      while (_metaCache.length >= _kMetaCacheMaxSize &&
          _metaCacheOrder.isNotEmpty) {
        final evict = _metaCacheOrder.removeAt(0);
        _metaCache.remove(evict);
      }
    }
    _metaCache[doctype] = meta;
    _metaCacheOrder.add(doctype);
  }

  /// Upserts the server's meta JSON for [doctype], preserving the existing
  /// row's `serverModifiedAt`, `isMobileForm`, `groupName`, and `sortOrder`
  /// values. Shared by [fetchAndStoreInDb] (prefetch path) and [getMeta]'s
  /// network-refresh branch so the four preserved fields cannot drift
  /// between the two write paths.
  Future<void> _upsertMetaJson(
    String doctype,
    Map<String, dynamic> metaData,
  ) async {
    final existing = await _database.doctypeMetaDao.findByDoctype(doctype);
    final entity = DoctypeMetaEntity(
      doctype: doctype,
      modified: metaData['modified']?.toString(),
      serverModifiedAt: existing?.serverModifiedAt,
      isMobileForm: existing?.isMobileForm ?? false,
      metaJson: jsonEncode(metaData),
      groupName: existing?.groupName,
      sortOrder: existing?.sortOrder,
    );
    if (existing != null) {
      await _database.doctypeMetaDao.updateDoctypeMeta(entity);
    } else {
      await _database.doctypeMetaDao.insertDoctypeMeta(entity);
    }
    // Server (re)wrote this doctype's meta — notify downstream caches
    // (e.g. OfflineRepository's per-doctype meta cache) so they don't
    // keep serving a stale snapshot for the rest of the session.
    onMetaRefreshed?.call(doctype);
  }

  /// Fetches from server and saves to DB only (no in-memory cache). Use for prefetch.
  Future<void> fetchAndStoreInDb(String doctype) async {
    final metaData = await _fetchMetaFromServer(doctype);
    await _upsertMetaJson(doctype, metaData);
    // Invalidate the in-memory LRU so the next getMeta() reload reads the
    // freshly-persisted row instead of serving the previous cached copy.
    // Without this, schema changes synced via prefetchToDb /
    // checkAndSyncDoctypes / resyncMobileConfiguration stay invisible to
    // the form layer until the entry is naturally evicted (15 reads later)
    // or the app restarts.
    clearDocTypeCache(doctype);
  }

  Future<Map<String, dynamic>> _fetchMetaFromServer(String doctype) async {
    final metaJson = await _client.doctype.getDocTypeMeta(doctype);
    Map<String, dynamic> metaData;
    if (metaJson.containsKey('docs') && metaJson['docs'] is List) {
      final docs = metaJson['docs'] as List;
      if (docs.isNotEmpty && docs[0] is Map<String, dynamic>) {
        metaData = docs[0] as Map<String, dynamic>;
      } else {
        metaData = metaJson;
      }
    } else if (metaJson.containsKey('message')) {
      final message = metaJson['message'];
      if (message is List && message.isNotEmpty) {
        metaData = message[0] as Map<String, dynamic>;
      } else if (message is Map<String, dynamic>) {
        metaData = message;
      } else {
        metaData = metaJson;
      }
    } else if (metaJson.containsKey('data')) {
      metaData = metaJson['data'] as Map<String, dynamic>;
    } else if (metaJson.containsKey('fields')) {
      metaData = metaJson;
    } else {
      metaData = metaJson;
    }
    if (!metaData.containsKey('fields') || metaData['fields'] is! List) {
      throw Exception(
        'Invalid metadata format: missing fields array. Response keys: ${metaData.keys.toList()}',
      );
    }
    return metaData;
  }

  /// Get metadata for a DocType. Loads only when required; uses bounded cache.
  /// Call [clearDocTypeCache] when leaving the screen to free memory.
  Future<DocTypeMeta> getMeta(
    String doctype, {
    bool forceRefresh = false,
  }) async {
    if (!forceRefresh && _metaCache.containsKey(doctype)) {
      _metaCacheOrder.remove(doctype);
      _metaCacheOrder.add(doctype);
      return _metaCache[doctype]!;
    }

    if (!forceRefresh) {
      final entity = await _database.doctypeMetaDao.findByDoctype(doctype);
      if (entity != null) {
        final meta = DocTypeMeta.fromJson(jsonDecode(entity.metaJson));
        // A cached meta with nothing renderable in it is a DEAD END, not a hit.
        //
        // This lookup is local-first, so whatever is in SQLite wins forever —
        // and a row can legitimately get there empty: persisted before the user
        // had read permission on the doctype, written by an older server that
        // answered `getdoctype` differently, or truncated by a partial sync.
        // From then on every form for that doctype renders
        // "No fields to display" and no amount of reopening, `flutter clean` or
        // reinstalling fixes it, because nothing ever asks the server again.
        //
        // Seen on `Assaying Parameters Child`: the server returns 5 fields with
        // `parameter_name` visible, while the device showed an empty sheet.
        //
        // Treat it as a miss and re-fetch. Costs one request in the broken case
        // and nothing at all in the normal one.
        if (_hasRenderableFields(meta)) {
          _putInCache(doctype, meta);
          return meta;
        }
        sdkLog(
          'MetaService: cached meta for "$doctype" has no renderable fields — '
          're-fetching from the server rather than serving an empty form.',
        );
      }
    }

    final Map<String, dynamic> metaData;
    try {
      metaData = await _fetchMetaFromServer(doctype);
    } catch (e) {
      // Offline, or the server refused. Fall back to whatever is cached — an
      // empty form is still better than an exception the caller cannot handle,
      // and this path only runs when the cache was already unusable.
      //
      // NEVER on forceRefresh: that contract is "bypass cache AND DB and hit
      // the server", so a caller who asked for fresh metadata has to be told
      // the fetch failed rather than handed the stale row it just rejected.
      if (forceRefresh) rethrow;
      final entity = await _database.doctypeMetaDao.findByDoctype(doctype);
      if (entity != null) {
        final meta = DocTypeMeta.fromJson(jsonDecode(entity.metaJson));
        _putInCache(doctype, meta);
        return meta;
      }
      rethrow;
    }
    final meta = DocTypeMeta.fromJson(metaData);
    await _upsertMetaJson(doctype, metaData);
    _putInCache(doctype, meta);
    return meta;
  }

  /// Whether [meta] describes a form that can actually render something.
  ///
  /// Layout breaks alone are not enough: a meta consisting only of Section/Tab
  /// breaks produces no tabs in `FrappeFormBuilder._buildTabsFor` and lands on
  /// the same "No fields to display" dead end as an empty list.
  static bool _hasRenderableFields(DocTypeMeta meta) => meta.fields.any(
    (f) =>
        f.fieldtype != 'Section Break' &&
        f.fieldtype != 'Column Break' &&
        f.fieldtype != 'Tab Break',
  );

  /// Prefetch doctypes into DB only (no in-memory cache). Use instead of loading all into memory.
  Future<void> prefetchToDb(List<String> doctypes) async {
    for (final doctype in doctypes) {
      try {
        await fetchAndStoreInDb(doctype);
      } catch (e, st) {
        debugPrint('MetaService.prefetchToDb($doctype) failed — $e\n$st');
      }
    }
  }

  /// Get metadata for multiple Doctypes (each loads into bounded cache).
  Future<Map<String, DocTypeMeta>> getMetas(List<String> doctypes) async {
    final Map<String, DocTypeMeta> result = {};
    for (final doctype in doctypes) {
      try {
        result[doctype] = await getMeta(doctype);
      } catch (e, st) {
        debugPrint('MetaService.getMetas getMeta($doctype) failed — $e\n$st');
      }
    }
    return result;
  }

  void clearCache() {
    _metaCache.clear();
    _metaCacheOrder.clear();
  }

  /// Clear one DocType from cache. Call when leaving form/list to free memory.
  void clearDocTypeCache(String doctype) {
    _metaCache.remove(doctype);
    _metaCacheOrder.remove(doctype);
  }

  Future<void> deleteMeta(String doctype) async {
    await _database.doctypeMetaDao.deleteByDoctype(doctype);
    clearDocTypeCache(doctype);
  }

  /// Checks mobile form doctypes and syncs meta if timestamps are newer.
  ///
  /// Compares serverModifiedAt from doctype_meta table with stored modified
  /// timestamps. Syncs any doctypes that have newer timestamps or are missing.
  /// Only checks doctypes marked as isMobileForm = true.
  Future<void> checkAndSyncDoctypes() async {
    try {
      // Get all mobile form doctypes from doctype_meta table
      final mobileFormMetas = await _database.doctypeMetaDao
          .findMobileFormDoctypes();

      if (mobileFormMetas.isEmpty) {
        return; // No mobile form doctypes to sync
      }

      final doctypesToSync = <String>[];

      for (final meta in mobileFormMetas) {
        if (meta.doctype.isEmpty) continue;
        final serverModifiedAt = meta.serverModifiedAt;

        if (serverModifiedAt == null || serverModifiedAt.isEmpty) {
          // No timestamp, sync if missing metadata
          if (meta.metaJson.isEmpty) {
            doctypesToSync.add(meta.doctype);
          }
          continue;
        }

        // Compare serverModifiedAt with stored modified timestamp
        final storedModified = meta.modified;
        if (storedModified == null ||
            storedModified.isEmpty ||
            _isTimestampNewer(serverModifiedAt, storedModified)) {
          doctypesToSync.add(meta.doctype);
        }
      }

      // Sync all doctypes that need updating
      if (doctypesToSync.isNotEmpty) {
        for (final doctype in doctypesToSync) {
          try {
            await fetchAndStoreInDb(doctype);
            // Successful re-fetch — clear any prior failure from the
            // observable surface so the counter goes back down.
            onMetaSyncRecovered?.call(doctype);
          } catch (e, st) {
            debugPrint(
              'MetaService.checkAndSyncDoctypes($doctype) failed — $e\n$st',
            );
            onMetaSyncFailure?.call(doctype, e);
            continue;
          }
        }
      }
    } catch (e, st) {
      // Don't block app launch on errors here, but surface them.
      debugPrint('MetaService.checkAndSyncDoctypes failed — $e\n$st');
      onMetaSyncFailure?.call('checkAndSyncDoctypes', e);
      return;
    }
  }

  /// Returns doctype names marked as mobile form (from login response, stored in doctype_meta).
  Future<List<String>> getMobileFormDoctypeNames() async {
    final list = await _database.doctypeMetaDao.findMobileFormDoctypes();
    return list.map((e) => e.doctype).where((d) => d.isNotEmpty).toList();
  }

  /// Returns doctypes grouped by group name, ordered by server-defined sort order.
  ///
  /// Groups are ordered by the lowest sortOrder of any member.
  /// Doctypes with null or empty groupName are placed in an 'Other' bucket.
  /// Returns an empty map if no mobile forms are configured.
  Future<Map<String, List<String>>> getMobileFormGroups() async {
    final list = await _database.doctypeMetaDao.findMobileFormDoctypes();
    final groups = <String, List<String>>{};
    for (final entity in list) {
      final group = (entity.groupName?.isNotEmpty == true)
          ? entity.groupName!
          : 'Other';
      groups.putIfAbsent(group, () => []).add(entity.doctype);
    }
    return groups;
  }

  /// Prefetch metadata for all mobile form doctypes into DB.
  Future<void> prefetchMobileFormDoctypes() async {
    try {
      final mobileFormMetas = await _database.doctypeMetaDao
          .findMobileFormDoctypes();
      final mobileFormDoctypes = mobileFormMetas
          .map((meta) => meta.doctype)
          .toList();

      if (mobileFormDoctypes.isNotEmpty) {
        await prefetchToDb(mobileFormDoctypes);
      }
    } catch (e, st) {
      debugPrint('MetaService.prefetchMobileFormDoctypes failed — $e\n$st');
      return;
    }
  }

  /// Alias for [prefetchMobileFormDoctypes]. Retained so the existing
  /// `FrappeSDK.syncAll()` facade keeps its semantic name; the underlying
  /// behavior (fetch + DB-store for every mobile form doctype, per-doctype
  /// debugPrint on failure) is identical because [prefetchToDb] — invoked
  /// by [prefetchMobileFormDoctypes] — loops `fetchAndStoreInDb` with the
  /// same per-doctype error guard.
  Future<void> syncAllMobileFormDoctypes() => prefetchMobileFormDoctypes();

  /// Updates mobile form doctypes in database from mobile form names list.
  ///
  /// Marks all existing mobile forms as false, then updates/creates entries
  /// for the provided mobile form names. Returns list of doctypes that need syncing.
  Future<List<String>> _updateMobileFormDoctypes(
    List<MobileFormName> mobileFormNames,
  ) async {
    // First, mark all existing mobile forms as false (loop 1)
    final allMetas = await _database.doctypeMetaDao.findAll();
    for (final meta in allMetas) {
      if (meta.isMobileForm) {
        final updatedMeta = DoctypeMetaEntity(
          doctype: meta.doctype,
          modified: meta.modified,
          serverModifiedAt: meta.serverModifiedAt,
          isMobileForm: false,
          metaJson: meta.metaJson,
          groupName: meta.groupName,
          sortOrder: meta.sortOrder,
        );
        await _database.doctypeMetaDao.updateDoctypeMeta(updatedMeta);
      }
    }

    // Now update/create entries for mobile forms (loop 2)
    final doctypesToSync = <String>[];

    for (int i = 0; i < mobileFormNames.length; i++) {
      final mfn = mobileFormNames[i];
      final doctype = mfn.mobileDoctype;
      if (doctype.isEmpty) continue;
      final existing = await _database.doctypeMetaDao.findByDoctype(doctype);

      if (existing != null) {
        // Has the server's mobile-config stamp for this doctype MOVED since
        // the last time we recorded it?
        //
        // This is deliberately server-vs-server. `doctype_meta_modified_at`
        // and the row's `modified` are NOT the same clock and must never be
        // compared: `modified` is the DocType document's own timestamp (from
        // `getdoctype`'s `docs[0].modified`), while `doctype_meta_modified_at`
        // tracks the mobile configuration for that doctype. In practice they
        // sit 47 minutes apart for `Farmer Registration` and FOURTEEN MONTHS
        // apart for `State`, so a cross-clock comparison reports every doctype
        // as permanently stale and re-fetches all of them on every launch.
        final serverModifiedAt = mfn.doctypeMetaModifiedAt;
        final needsSync =
            serverModifiedAt != null &&
            serverModifiedAt.isNotEmpty &&
            (existing.serverModifiedAt == null ||
                existing.serverModifiedAt!.isEmpty ||
                _isTimestampNewer(
                  serverModifiedAt,
                  existing.serverModifiedAt!,
                ));

        // Update existing entry with mobile form info.
        //
        // `serverModifiedAt` is deliberately PRESERVED here, not advanced to
        // `mfn.doctypeMetaModifiedAt`. This row is about to be queued for a
        // re-fetch that can fail — 401, 417 and transport errors are all live
        // on this wire, and the fetch loop below catches per doctype and
        // continues. Advancing the stamp now would mark the doctype fresh while
        // it still holds the OLD `metaJson`: on the next launch the server's
        // stamp equals the row's, `needsSync` is false, `metaJson` is non-empty
        // so the placeholder escape hatch does not fire either, and the doctype
        // is stale FOREVER — one transient network blip permanently poisons it.
        //
        // The stamp is advanced by `resyncMobileConfiguration` only after
        // `fetchAndStoreInDb` has actually returned, via
        // `doctypeMetaDao.setServerModifiedAt`.
        final updatedMeta = DoctypeMetaEntity(
          doctype: doctype,
          modified: existing.modified,
          serverModifiedAt: existing.serverModifiedAt,
          isMobileForm: true,
          metaJson: existing.metaJson,
          groupName: mfn.groupName,
          sortOrder: i,
        );
        await _database.doctypeMetaDao.updateDoctypeMeta(updatedMeta);

        // Add to sync list if timestamp is newer or metadata is missing
        if (needsSync ||
            existing.metaJson.isEmpty ||
            existing.metaJson == '{}') {
          doctypesToSync.add(doctype);
        }
      } else {
        // Create new entry with mobile form info (metaJson will be empty until fetched)
        final newMeta = DoctypeMetaEntity(
          doctype: doctype,
          modified: null,
          serverModifiedAt: mfn.doctypeMetaModifiedAt,
          isMobileForm: true,
          metaJson: '{}', // Empty until metadata is fetched
          groupName: mfn.groupName,
          sortOrder: i,
        );
        await _database.doctypeMetaDao.insertDoctypeMeta(newMeta);
        doctypesToSync.add(doctype);
      }
    }

    return doctypesToSync;
  }

  /// Thin wrapper for testing purposes only.
  @visibleForTesting
  Future<List<String>> updateMobileFormDoctypesForTest(
    List<MobileFormName> mobileFormNames,
  ) => _updateMobileFormDoctypes(mobileFormNames);

  /// Removes only the forms the locally-synced permission matrix
  /// AFFIRMATIVELY denies — a `doctype_permission` row exists AND its `read`
  /// is false.
  ///
  /// SUBTRACT-ONLY, never intersect. A doctype with NO row is KEPT. That
  /// asymmetry is the whole design: `PermissionService` defaults a cache miss
  /// to ALLOW, so a positive filter (`where(canRead)`) is a no-op once
  /// permissions are synced and, on a first launch where the matrix has not
  /// synced yet, would rest entirely on that default. Getting it wrong in the
  /// other direction empties the workspace on first launch — a worse failure
  /// than the churn this guards against.
  ///
  /// Reads the DAO directly rather than taking a `PermissionService`: the
  /// default-allow resolver is precisely what must NOT be applied here.
  @visibleForTesting
  Future<List<MobileFormName>> dropDeniedFormsForTest(
    List<MobileFormName> mobileFormNames,
  ) => _dropDeniedForms(mobileFormNames);

  Future<List<MobileFormName>> _dropDeniedForms(
    List<MobileFormName> mobileFormNames,
  ) async {
    // ONE query for the whole list. The affirmative-denial set is what this
    // method needs, and asking for it directly keeps the subtract-only
    // semantics intact: an absent row is not in the set, so it is kept.
    final Set<String> readDenied;
    try {
      readDenied = await _database.doctypePermissionDao
          .findReadDeniedDoctypes();
    } catch (e, st) {
      // A permission-table read failure must not shrink the workspace.
      // Fail OPEN — keep every form and let the per-doctype 403 handle it.
      sdkLog(
        'MetaService._dropDeniedForms: permission lookup failed, keeping '
        'every form — $e\n$st',
      );
      return mobileFormNames;
    }
    final kept = <MobileFormName>[];
    final dropped = <String>[];
    for (final mfn in mobileFormNames) {
      final doctype = mfn.mobileDoctype;
      if (doctype.isNotEmpty && readDenied.contains(doctype)) {
        dropped.add(doctype);
        continue;
      }
      kept.add(mfn);
    }
    if (dropped.isNotEmpty) {
      sdkLog(
        'MetaService.resyncMobileConfiguration: guest fallback list scoped '
        'against the local permission matrix, dropped ${dropped.length} '
        'read-denied doctype(s): ${dropped.join(', ')}',
      );
    }
    return kept;
  }

  /// Statuses on which the mobile-configuration fetch is retried
  /// unauthenticated: the two ways a server-side permission filter can refuse
  /// rather than return a filtered list. Deliberately excludes 401 (a dead
  /// credential, which must surface) and every 5xx.
  static const Set<int?> _permissionFilterStatuses = <int?>{403, 417};

  /// Fetches mobile configuration from server and resyncs doctype metadata.
  ///
  /// Calls `/api/v2/method/mobile_auth.configuration` to get updated mobile form list
  /// and syncs doctype metadata for any doctypes that have been updated or are new.
  ///
  /// Throws if not authenticated or API call fails.
  Future<void> resyncMobileConfiguration() async {
    try {
      // Authenticated call so the server can filter to the doctypes this user
      // can read. The DEPLOYED endpoint's authenticated filter can raise a
      // PermissionError (a throwing `has_permission` on `DocType`) instead of
      // returning a filtered list. Since the method is `allow_guest=True`,
      // fall back to an unauthenticated fetch to still obtain the mobile
      // workspace list.
      // SDK-WORKAROUND: backend `get_mobile_configuration` should use throw=False.
      //
      // The fallback is scoped to the PERMISSION statuses ON PURPOSE — an
      // unscoped catch here is a correctness hazard, not merely untidy:
      //
      //  * On 401 it would answer a DEAD CREDENTIAL with the GUEST workspace
      //    list. That list is unfiltered, `_updateMobileFormDoctypes` marks
      //    every entry `isMobileForm: true`, and the expired session is hidden
      //    behind a workspace that looks populated.
      //  * On a transport failure (offline) it would swap one failed request
      //    for a second failed request and report the offline user's error as
      //    a permission story.
      //
      // Both paths also manufacture exactly the churn the terminal-demotion
      // guard exists to suppress: unreadable doctypes enter the closure, 403,
      // get demoted, and are re-promoted on the next launch.
      //
      // 417 is in the set alongside 403 because the commit that introduced
      // this workaround recorded the SYMPTOM ("can raise a PermissionError")
      // but never the observed STATUS. Frappe maps `frappe.PermissionError` to
      // 403, but a `has_permission` hook that raises through a bare
      // `frappe.throw()` surfaces as `ValidationException` (417) — the same
      // asymmetry documented on [isDefinitiveRefreshRejection]. Scoping to 403
      // alone would make this method THROW on a deployment where it previously
      // recovered, silently killing the workaround. Widening is safe here
      // precisely because it is scoped to this ONE call site: a 417 from a
      // configuration fetch is not a statement about the credential, and
      // nothing on this path wipes a token.
      //
      // 401, 5xx and transport failures still rethrow — those are the cases
      // the unscoped catch got wrong.
      dynamic result;
      var usedGuestFallback = false;
      try {
        result = await _client.rest.get(
          '/api/v2/method/mobile_auth.configuration',
        );
      } on FrappeException catch (e, st) {
        if (!_permissionFilterStatuses.contains(e.statusCode)) rethrow;
        sdkLog(
          'MetaService.resyncMobileConfiguration: authenticated config fetch '
          'returned ${e.statusCode}, retrying unauthenticated — $e\n$st',
        );
        result = await _client.rest.getPublic(
          '/api/v2/method/mobile_auth.configuration',
        );
        usedGuestFallback = true;
      }

      // Parse response - response structure: {"data": [...]}
      final response = result is Map<String, dynamic>
          ? (result['data'] is List
                ? result['data']
                : result['message'] is List
                ? result['message']
                : [])
          : <dynamic>[];

      if (response.isEmpty) {
        return; // No mobile forms configured
      }

      // Parse mobile form names
      final mobileFormNames = (response as List)
          .map((json) => MobileFormName.fromJson(json as Map<String, dynamic>))
          .toList();

      if (mobileFormNames.isEmpty) {
        return;
      }

      // The guest list is UNFILTERED — the server could not scope it to this
      // user. Subtract anything the locally-synced permission matrix
      // affirmatively denies before it reaches the mobile-form set. Applied to
      // the fallback branch ONLY: the authenticated response is already
      // server-filtered, and intersecting THAT against a possibly-stale local
      // matrix could subtract forms the user can legitimately read.
      final scopedFormNames = usedGuestFallback
          ? await _dropDeniedForms(mobileFormNames)
          : mobileFormNames;

      if (scopedFormNames.isEmpty) {
        return;
      }

      // Update mobile form doctypes and get list of doctypes to sync
      final doctypesToSync = await _updateMobileFormDoctypes(scopedFormNames);

      // Sync all doctypes that need updating.
      //
      // The staleness stamp is advanced HERE, per doctype, and only once the
      // fetch has actually landed — see the note in `_updateMobileFormDoctypes`
      // on why writing it at queue time permanently poisons a row whose fetch
      // fails. A doctype that throws keeps its OLD stamp, so the next launch
      // sees the server's newer stamp and queues it again.
      if (doctypesToSync.isNotEmpty) {
        final stampFor = <String, String?>{
          for (final m in scopedFormNames)
            m.mobileDoctype: m.doctypeMetaModifiedAt,
        };
        for (final doctype in doctypesToSync) {
          try {
            await fetchAndStoreInDb(doctype);
          } catch (e, st) {
            debugPrint(
              'MetaService.resyncMobileConfiguration($doctype) failed — $e\n$st',
            );
            onMetaSyncFailure?.call(doctype, e);
            continue;
          }
          final stamp = stampFor[doctype];
          if (stamp != null && stamp.isNotEmpty) {
            await _database.doctypeMetaDao.setServerModifiedAt(doctype, stamp);
          }
        }
      }
    } catch (e) {
      // Re-throw to let caller handle errors
      if (e is Exception) rethrow;
      throw Exception('Failed to resync mobile configuration: $e');
    }
  }

  /// Compares two timestamp strings to check if first is newer than second.
  ///
  /// Handles formats like "2026-02-09 17:29:03" or ISO 8601.
  bool _isTimestampNewer(String timestamp1, String timestamp2) {
    try {
      final date1 = _parseTimestamp(timestamp1);
      final date2 = _parseTimestamp(timestamp2);
      if (date1 == null || date2 == null) return false;
      return date1.isAfter(date2);
    } catch (e, st) {
      debugPrint(
        'MetaService._isTimestampNewer($timestamp1, $timestamp2) failed — $e\n$st',
      );
      return false;
    }
  }

  DateTime? _parseTimestamp(String timestamp) {
    try {
      // Try ISO 8601 format first
      if (timestamp.contains('T')) {
        return DateTime.parse(timestamp);
      }
      // Try "YYYY-MM-DD HH:MM:SS" format
      if (timestamp.contains(' ')) {
        return DateTime.parse(timestamp.replaceAll(' ', 'T'));
      }
      // Try just date
      return DateTime.parse(timestamp);
    } catch (e, st) {
      debugPrint('MetaService._parseTimestamp($timestamp) failed — $e\n$st');
      return null;
    }
  }

  // ─────────── P2: offline-first extensions ───────────

  /// Computes the closure of doctypes reachable from [entryPoints] via
  /// `Link` + `Table` + `Table MultiSelect` edges. Spec §3.2.
  ///
  /// [metaFetcher] is an optional injection seam used by tests; in
  /// production it defaults to [getMeta] which itself uses the in-memory
  /// LRU + DB cache + network fallback chain.
  Future<ClosureResult> closure(
    List<String> entryPoints, {
    MetaFetcher? metaFetcher,
  }) async {
    return ClosureBuilder.build(
      entryPoints: entryPoints,
      metaFetcher: metaFetcher ?? (dt) => getMeta(dt),
    );
  }

  /// Returns the latest server `modified` per doctype. If [probe] is
  /// supplied and detects the optional bulk endpoint, one round-trip is
  /// used; otherwise it falls back to per-doctype GETs.
  ///
  /// [watermarkFetcher] overrides the per-doctype fallback for tests.
  Future<Map<String, String?>> refreshWatermarks(
    List<String> doctypes, {
    BulkWatermarkProbe? probe,
    Future<String?> Function(String doctype)? watermarkFetcher,
    void Function(double progress, String step)? onProgress,
  }) async {
    if (probe != null) {
      final detection = await probe.detect(candidates: doctypes);
      if (detection.available) {
        onProgress?.call(0.5, 'Checking schemas via bulk probe...');
        final rows = await probe.fetchWatermarks(doctypes);
        return {
          for (final r in rows)
            r['doctype'] as String: r['modified'] as String?,
        };
      }
    }
    final out = <String, String?>{};
    final fallback =
        watermarkFetcher ?? (dt) => _client.doctype.getDocTypeWatermark(dt);
    for (int i = 0; i < doctypes.length; i++) {
      final dt = doctypes[i];
      onProgress?.call(i / doctypes.length, 'Checking schema for $dt...');
      try {
        out[dt] = await fallback(dt);
      } catch (e, st) {
        debugPrint(
          'MetaService.refreshWatermarks fallback($dt) failed — $e\n$st',
        );
        out[dt] = null;
      }
    }
    return out;
  }

  /// For each doctype, compares local `meta_watermark` against the server
  /// `modified`. On mismatch: refetches the full meta, runs [MetaDiffer],
  /// applies the diff via [MetaMigration], and persists fresh meta_json,
  /// meta_watermark, and dep_graph_json. Spec §4.9.
  ///
  /// Each doctype is processed independently — a failure on one (network
  /// error fetching meta, malformed payload, ALTER TABLE conflict, …) does
  /// NOT abort the rest of the batch. Returns a [MetaUpdateResult]
  /// summarising successes and per-doctype failures so the caller can
  /// surface them to the user or retry later.
  Future<MetaUpdateResult> ensureUpToDate(
    List<String> doctypes, {
    BulkWatermarkProbe? probe,
    Future<String?> Function(String doctype)? watermarkFetcher,
    MetaFetcher? metaFetcher,
    void Function(double progress, String step)? onProgress,
  }) async {
    final dao = _database.doctypeMetaDao;
    final fetchMeta = metaFetcher ?? (dt) => getMeta(dt, forceRefresh: true);
    final serverMarks = await refreshWatermarks(
      doctypes,
      probe: probe,
      watermarkFetcher: watermarkFetcher,
      onProgress: (p, step) {
        onProgress?.call(p * 0.5, step);
      },
    );

    final updated = <String>[];
    final unchanged = <String>[];
    final failed = <String, String>{};

    for (int i = 0; i < doctypes.length; i++) {
      final dt = doctypes[i];
      onProgress?.call(
        0.5 + (i / doctypes.length) * 0.5,
        'Updating schema for $dt...',
      );
      try {
        final newMark = serverMarks[dt];
        if (newMark == null) {
          // No watermark = nothing to compare. Treat as "unchanged" rather
          // than silently failing — caller decides whether to retry.
          unchanged.add(dt);
          continue;
        }
        // Best-effort read: not wrapped in a transaction, so a concurrent
        // PullEngine job updating this row's last_ok_cursor could cause SQLite
        // to re-read the row. SQLite WAL guarantees no torn read, but the
        // watermark value here may be one write behind. Worst case: unnecessary
        // meta re-fetch on the next cycle, not data corruption.
        final localMark = await dao.getMetaWatermark(dt);
        if (localMark == newMark) {
          unchanged.add(dt);
          continue;
        }

        final fresh = await fetchMeta(dt);
        final oldJson = await dao.getMetaJson(dt);
        final old = (oldJson == null || oldJson.isEmpty || oldJson == '{}')
            ? DocTypeMeta(name: dt, fields: const [])
            : DocTypeMeta.fromJson(jsonDecode(oldJson) as Map<String, dynamic>);

        final diff = MetaDiffer.diff(oldMeta: old, newMeta: fresh);
        if (!diff.isNoOp) {
          final tableName = await dao.getTableName(dt);
          if (tableName != null) {
            await MetaMigration.apply(
              _database.rawDatabase,
              diff,
              tableName: tableName,
            );
          }
        }
        // Route through _upsertMetaJson (not the DAO) so onMetaRefreshed fires
        // and downstream caches (OfflineRepository) are invalidated — a wired
        // ensureUpToDate must not write fresh schema without evicting them.
        await _upsertMetaJson(dt, fresh.toJson());
        await dao.setMetaWatermark(dt, newMark);
        final dg = DependencyGraphBuilder.buildOutgoing(fresh);
        await dao.setDepGraphJson(dt, jsonEncode(dg.toJson()));
        updated.add(dt);
      } catch (e, st) {
        debugPrint('MetaService.ensureUpToDate($dt) failed — $e\n$st');
        failed[dt] = e.toString();
      }
    }

    return MetaUpdateResult(
      updated: updated,
      unchanged: unchanged,
      failed: failed,
    );
  }

  /// Reads the cached dep graph for a doctype, or null if none persisted yet.
  Future<DepGraph?> depGraphFor(String doctype) async {
    final raw = await _database.doctypeMetaDao.getDepGraphJson(doctype);
    if (raw == null) return null;
    return DepGraph.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  /// Persists each per-doctype graph in [closure] onto
  /// `doctype_meta.dep_graph_json` so later phases (PullEngine, push tier
  /// computer) can read them without rebuilding from meta.
  Future<void> primeDepGraphs(ClosureResult closure) async {
    final dao = _database.doctypeMetaDao;
    for (final dt in closure.doctypes) {
      final g = closure.graph[dt];
      if (g == null) continue;
      await dao.setDepGraphJson(dt, jsonEncode(g.toJson()));
    }
  }
}

/// Outcome of a [MetaService.ensureUpToDate] call. Each doctype lands in
/// exactly one of the three buckets — `updated` (watermark advanced and
/// schema/meta refreshed), `unchanged` (already in sync or no server
/// watermark available), or `failed` (with the stringified error). Allows
/// the caller to surface partial results to the user without aborting the
/// rest of the batch on a single error.
class MetaUpdateResult {
  final List<String> updated;
  final List<String> unchanged;
  final Map<String, String> failed;

  const MetaUpdateResult({
    required this.updated,
    required this.unchanged,
    required this.failed,
  });

  bool get allSucceeded => failed.isEmpty;
}
